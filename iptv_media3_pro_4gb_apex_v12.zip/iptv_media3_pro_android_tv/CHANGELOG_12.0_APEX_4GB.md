# StreamX Media3 Pro — v12.0 Apex 4GB Flagship Edition

Built directly on top of **StreamX Media3 Pro v12.0 Quantum-Lite / 5.2.0 Ultimate**, this release unlocks the full hardware capabilities of **4GB RAM Android TVs**:

1. **3-Slot Bidirectional Dual/Triple ExoPlayer Swap (`PlayerActivity.kt`)**:
   - `ActivePlayer` plays Channel `N` while `NextPrewarmPlayer` (`N+1`) and `PrevPrewarmPlayer` (`N-1`) silently pre-prepare adjacent channels (`volume = 0f`) for `<80ms` surface swaps, with automatic 2-codec hardware fallback.
2. **60-Second Mega Buffer, 20-Second Live RAM Rewind & 48MB `SimpleCache` (`PlayerActivity.kt`, `StreamPreFetcher.kt`)**:
   - `minBufferMs = 25000`, `maxBufferMs = 60000`, `bufferForPlaybackMs = 150`, `bufferForPlaybackAfterRebufferMs = 600`, `setBackBuffer(20000, true)`, `.setPrioritizeTimeOverSizeThresholds(true)`, and 48MB `SimpleCache`.
3. **Full 4K 60FPS Tunneled Playback & Seamless Refresh-Rate Sync (`PlayerActivity.kt`)**:
   - Removes 1080p/8Mbps caps, enables `DefaultTrackSelector` hardware tunneling (`setTunnelingEnabled(true)`), and sets `C.VIDEO_CHANGE_FRAME_RATE_STRATEGY_ONLY_IF_SEAMLESS`.
4. **Live Mini-TV Floating Mode & System PiP (`PlayerActivity.kt`)**:
   - Smoothly shrinks `PlayerView` into a floating corner PiP window on GPU when the Channel Sidebar or EPG dialog opens, plus automatic Android TV System PiP on `onUserLeaveHint()`.
5. **Full `ARGB_8888` (`256x256px`) 4K Logo Cache (`PlayerActivity.kt`, `NetworkClient.kt`, `StreamXApp.kt`)**:
   - `DecodeFormat.PREFER_ARGB_8888` at `256x256` with `MemoryCategory.HIGH`, 36MB RAM LRU cache, and 100MB disk cache.
6. **Expanded OkHttp Connection Pool (`NetworkClient.kt`)**:
   - `Dispatcher.maxRequests = 16`, `maxRequestsPerHost = 6`, and `ConnectionPool(20, 10, TimeUnit.MINUTES)`.
