package com.harindra.iptvpro

import android.graphics.Bitmap
import android.util.LruCache
import okhttp3.Cache
import okhttp3.ConnectionPool
import okhttp3.Dispatcher
import okhttp3.Dns
import okhttp3.OkHttpClient
import okhttp3.Protocol
import java.io.File
import java.net.InetAddress
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * v12.0 Apex 4GB Flagship Edition — Expanded OkHttp Connection Pool (20 idle, 10m keep-alive),
 * Dispatcher (maxRequests = 16, maxRequestsPerHost = 6), Bounded In-Memory DNS Cache,
 * and 36MB RAM LRU + 100MB Disk Cache configuration for 4K ARGB_8888 Channel Logos.
 */
object NetworkClient {
    private const val DNS_TTL_MS = 30L * 60L * 1000L // 30-minute TTL
    private const val MAX_DNS_ENTRIES = 100
    const val LOGO_RAM_LRU_BYTES = 36 * 1024 * 1024 // 36 MB RAM LRU cache for 4K ARGB_8888 logos (Upgrade 5)
    const val LOGO_DISK_CACHE_BYTES = 100L * 1024L * 1024L // 100 MB disk cache for 4K logos (Upgrade 5)

    // Upgrade 5: 36MB In-Memory ARGB_8888 Bitmap LRU Cache for 256x256 4K TV Channel Icons
    val logoRamLruCache: LruCache<String, Bitmap> = object : LruCache<String, Bitmap>(LOGO_RAM_LRU_BYTES) {
        override fun sizeOf(key: String, value: Bitmap): Int {
            return value.allocationByteCount.coerceAtLeast(1024)
        }
    }

    @Volatile
    private var diskHttpCache: Cache? = null

    fun initLogoDiskCache(cacheRootDir: File) {
        if (diskHttpCache != null) return
        runCatching {
            val dir = File(cacheRootDir, "streamx_4k_logo_disk_cache_100mb")
            if (!dir.exists()) dir.mkdirs()
            diskHttpCache = Cache(dir, LOGO_DISK_CACHE_BYTES)
        }
    }

    private data class DnsEntry(
        val addresses: List<InetAddress>,
        val timestampMs: Long
    )

    private val dnsCache = ConcurrentHashMap<String, DnsEntry>(128)

    val quantumDns: Dns = object : Dns {
        override fun lookup(hostname: String): List<InetAddress> {
            val key = hostname.lowercase()
            val now = System.currentTimeMillis()
            val cached = dnsCache[key]
            if (cached != null && (now - cached.timestampMs) < DNS_TTL_MS && cached.addresses.isNotEmpty()) {
                return cached.addresses
            }
            val resolved = Dns.SYSTEM.lookup(hostname)
            if (resolved.isNotEmpty()) {
                if (dnsCache.size >= MAX_DNS_ENTRIES) {
                    val oldestKey = dnsCache.entries.minByOrNull { it.value.timestampMs }?.key
                    if (oldestKey != null) dnsCache.remove(oldestKey)
                }
                dnsCache[key] = DnsEntry(resolved, now)
            }
            return resolved
        }
    }

    // Upgrade 6: Dispatcher.maxRequests = 16, maxRequestsPerHost = 6
    private fun dispatcher(max: Int = 16, perHost: Int = 6) = Dispatcher().apply {
        maxRequests = max
        maxRequestsPerHost = perHost
    }

    // Upgrade 6: ConnectionPool(20, 10, TimeUnit.MINUTES) for 4GB RAM TV
    private fun pool(maxIdle: Int = 20) = ConnectionPool(maxIdle, 10, TimeUnit.MINUTES)

    private val metadataDispatcher by lazy { dispatcher(max = 16, perHost = 6) }
    private val apiDispatcher by lazy { dispatcher(max = 16, perHost = 6) }
    private val streamDispatcher by lazy { dispatcher(max = 16, perHost = 6) }

    private val metadataPool by lazy { pool(maxIdle = 20) }
    private val apiPool by lazy { pool(maxIdle = 20) }
    private val streamPool by lazy { pool(maxIdle = 20) }

    val fastMetaClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .dns(quantumDns)
            .protocols(listOf(Protocol.HTTP_2, Protocol.HTTP_1_1))
            .connectionPool(metadataPool)
            .dispatcher(metadataDispatcher)
            .apply { diskHttpCache?.let { cache(it) } }
            .connectTimeout(4, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .writeTimeout(8, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    val apiClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .dns(quantumDns)
            .protocols(listOf(Protocol.HTTP_2, Protocol.HTTP_1_1))
            .connectionPool(apiPool)
            .dispatcher(apiDispatcher)
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(45, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    val streamClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .dns(quantumDns)
            .protocols(listOf(Protocol.HTTP_2, Protocol.HTTP_1_1))
            .connectionPool(streamPool)
            .dispatcher(streamDispatcher)
            .connectTimeout(4, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(10, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }
}
