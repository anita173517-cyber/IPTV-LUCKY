package com.harindra.iptvpro

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.ActivityManager
import android.app.PictureInPictureParams
import android.content.ComponentCallbacks2
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Debug
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.util.Log
import android.util.Rational
import android.util.SparseIntArray
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.exoplayer.upstream.DefaultAllocator
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.MemoryCategory
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.security.MessageDigest
import java.util.Arrays
import java.util.Locale

data class TvThemePalette(
    val name: String,
    val accentHex: String,
    val badgeTextHex: String,
    val statusHex: String
)

enum class BufferProfile(
    val id: String,
    val label: String,
    val minBufferMs: Int,
    val maxBufferMs: Int,
    val playBufferMs: Int,
    val rebufferMs: Int,
    val targetBytes: Int,
    val backBufferMs: Int,
    val prioritizeTimeOverSize: Boolean
) {
    // Upgrade 2: 60-Second Mega Buffer & 20-Second Live Rewind for 4GB RAM Flagship TV
    APEX_4GB_FLAGSHIP(
        "APEX_4GB",
        "Apex 4GB Flagship (60s Mega Buffer • 20s Live Rewind)",
        25000,
        60000,
        150,
        600,
        32 * 1024 * 1024,
        20000,
        true
    ),
    ULTRA_SPORTS_4K(
        "ULTRA_SPORTS",
        "Ultra Sports 4K 60fps (30s Buffer • 150ms Start)",
        15000,
        30000,
        150,
        500,
        24 * 1024 * 1024,
        15000,
        true
    ),
    BALANCED(
        "BALANCED",
        "Balanced HD/4K (20s Buffer • 10s Rewind)",
        12000,
        24000,
        200,
        600,
        16 * 1024 * 1024,
        10000,
        true
    ),
    LOW_MEMORY_512MB(
        "LOW_MEM",
        "Low Memory Fallback (5MB Cap)",
        10000,
        20000,
        120,
        600,
        5 * 1024 * 1024,
        0,
        false
    );

    companion object {
        fun fromId(id: String?): BufferProfile {
            return entries.firstOrNull { it.id == id } ?: APEX_4GB_FLAGSHIP
        }
    }
}

@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {

    // Upgrade 1: 3-Slot Bidirectional Dual/Triple ExoPlayer Swap Engine for 4GB RAM TV
    private var exoPlayer: ExoPlayer? = null               // Slot 1: ActivePlayer (Channel N)
    private var nextPrewarmPlayer: ExoPlayer? = null       // Slot 2: NextPrewarmPlayer (Channel N+1, muted)
    private var prevPrewarmPlayer: ExoPlayer? = null       // Slot 3: PrevPrewarmPlayer (Channel N-1, muted)
    private var nextPrewarmUrl: String = ""
    private var prevPrewarmUrl: String = ""
    private var allowThirdCodecSlot: Boolean = true        // Gracefully falls back to 2 players if chipset limits codecs

    private var sharedAllocator: DefaultAllocator? = null
    private var cacheDataSourceFactory: CacheDataSource.Factory? = null
    private var hlsChunklessFactory: HlsMediaSource.Factory? = null

    private lateinit var playerView: PlayerView
    private lateinit var topControlBar: View
    private lateinit var leftChannelDrawer: View
    private lateinit var channelListRecycler: RecyclerView
    private lateinit var tvEmptyDrawer: TextView
    private lateinit var osdBanner: View
    private lateinit var tvChannelNumber: TextView
    private lateinit var tvChannelName: TextView
    private lateinit var tvChannelCategory: TextView
    private lateinit var tvEpgNow: TextView
    private lateinit var tvActiveSectionBadge: TextView
    private lateinit var btnToggleFavorite: Button
    private lateinit var btnRecallChannel: Button
    private lateinit var btnToggleDrawer: Button
    private lateinit var tabAllChannels: Button
    private lateinit var channelSearch: EditText
    private lateinit var categoryFilter: Spinner
    private lateinit var channelLogo: ImageView

    // DTH Set-Top-Box Startup Overlay Views
    private lateinit var dthBootOverlay: View
    private lateinit var vSignalWaveOuter: View
    private lateinit var vSignalWaveInner: View
    private lateinit var tvBootHeadline: TextView
    private lateinit var tvBootStageStatus: TextView
    private lateinit var tvBootSubDetail: TextView
    private lateinit var bootProgressBar: ProgressBar
    private var outerWaveAnimator: ObjectAnimator? = null
    private var innerWaveAnimator: ObjectAnimator? = null
    private var satellitePulseAnimator: ObjectAnimator? = null
    private var isBootOverlayVisible: Boolean = true
    private var hasRenderedVideoFrame: Boolean = false
    private var isMiniTvFloating: Boolean = false

    // Real Startup & Runtime Diagnostic Timings
    private var processStartElapsedMs: Long = 0L
    private var firstUiFrameMs: Long = 0L
    private var bootReadyElapsedMs: Long = 0L
    private var firstVideoFrameMs: Long = 0L
    private var lastPlaylistLoadDurationMs: Long = 0L
    private var lastSwitchStartElapsedMs: Long = 0L
    private var lastChannelSwitchMs: Long = 0L
    private var totalDeviceRamMb: Long = 4096L
    private var maxPlaylistLimit: Int = 60_000

    private lateinit var channelAdapter: ChannelDrawerAdapter
    private var searchQuery: String = ""
    private var selectedCategory: String = "All categories"
    private var suppressCategoryCallback: Boolean = false
    private var epgMap: Map<String, Pair<String, String>> = emptyMap()

    // Primitive IntArray Windowed Pagination
    private var fullFilteredIndices: IntArray = IntArray(0)
    private var currentPagedLimit: Int = 2000
    private val pageStepSize: Int = 2000

    private var filterJob: Job? = null
    private var loadChannelsJob: Job? = null
    private var epgLoadJob: Job? = null
    private var bgSyncJob: Job? = null

    private val xtreamRepo = XtreamRepository()
    private lateinit var profileStore: ProfileStore
    private lateinit var channelCache: ChannelCacheStore
    private lateinit var epgCache: EpgCacheStore
    private var connectivityManager: ConnectivityManager? = null
    private var networkCallbackRegistered: Boolean = false

    private var activeSourceType: ProfileType? = null
    private var activeXtreamCreds: XtreamCredentials? = null
    private var activeM3uInput: String = ""
    private var activeM3uLabel: String = "M3U"

    private var liveResolutionLabel: String = "4K Auto"
    private var liveTelemetryDetail: String = ""
    private var liveStatusLabel: String = "🟢 Live"
    private var subtitlesEnabled: Boolean = false
    private var selectedQualityLabel: String = "Auto"
    private var activeBufferProfile: BufferProfile = BufferProfile.APEX_4GB_FLAGSHIP
    private var autoBootEnabled: Boolean = true
    private var autoResumeEnabled: Boolean = true
    private var currentPlayingStreamUrl: String = ""
    private var usingBackupStream: Boolean = false
    private var unlockedSessionCategories: MutableSet<String> = HashSet()

    // Upgrade 5: Full-Color ARGB_8888 (256x256px) 4K Quality Logo Decoding
    private val logoRequestOptions = RequestOptions()
        .format(DecodeFormat.PREFER_ARGB_8888)
        .override(256, 256)
        .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
        .dontAnimate()
        .placeholder(android.R.drawable.ic_media_play)
        .error(android.R.drawable.ic_media_play)

    private val themes = listOf(
        TvThemePalette("Cyan Cyber Glass", "#0284C7", "#38BDF8", "#34D399"),
        TvThemePalette("Royal Gold VIP", "#D97706", "#FBBF24", "#FDE047"),
        TvThemePalette("Emerald Matrix", "#059669", "#34D399", "#6EE7B7"),
        TvThemePalette("Purple Synthwave", "#7C3AED", "#C084FC", "#38BDF8"),
        TvThemePalette("Crimson AMOLED", "#E11D48", "#FB7185", "#FBBF24")
    )
    private var currentThemeIndex: Int = 0

    private val playlistPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                Log.w("StreamX", "Persistable URI permission note: ${e.message}")
            }
            importLocalM3uUri(uri)
        }
    }

    private val uiHandler = Handler(Looper.getMainLooper())

    private val hideOsdRunnable: Runnable = Runnable {
        osdBanner.animate()
            .alpha(0f)
            .setDuration(150L)
            .withLayer()
            .withEndAction {
                osdBanner.visibility = View.GONE
                osdBanner.alpha = 1f
            }
            .start()
        if (leftChannelDrawer.visibility != View.VISIBLE) {
            topControlBar.visibility = View.GONE
        }
    }

    private val commitPlaybackRunnable: Runnable = Runnable {
        startPlaybackForCurrentChannel(forceReload = false)
    }

    private val retryPlaybackRunnable: Runnable = Runnable {
        val player = exoPlayer ?: return@Runnable
        if (allChannels.isNotEmpty()) {
            player.seekToDefaultPosition()
            player.prepare()
            player.playWhenReady = true
        }
    }

    // Upgrade 1: Pre-warm Adjacent N+1 and N-1 Player Slots once ActivePlayer is stable
    private val prewarmAdjacentSlotsRunnable: Runnable = Runnable {
        prewarmAdjacentPlayerSlotsSafe()
    }

    // Fast 2.5s Playback Stall Watchdog + Smart Auto-Failover to backupUrl
    private var stallRecoveryCount: Int = 0
    private val stallWatchdogRunnable: Runnable = object : Runnable {
        override fun run() {
            val player = exoPlayer ?: return
            if (player.playbackState == Player.STATE_BUFFERING && allChannels.isNotEmpty()) {
                val ch = allChannels.getOrNull(currentChannelIndex)
                if (ch != null && !usingBackupStream && ch.backupUrl.isNotBlank()) {
                    usingBackupStream = true
                    stallRecoveryCount = 0
                    Log.w("StreamX", "2.5s Watchdog failover to backupUrl for ${ch.name}")
                    liveStatusLabel = "⚡ Backup Stream"
                    updateOsdForCurrentChannel()
                    playSpecificStreamUrl(ch.backupUrl)
                    return
                }
                if (stallRecoveryCount < 3) {
                    stallRecoveryCount++
                    Log.w("StreamX", "2.5s Stall Watchdog triggered (${stallRecoveryCount}/3): reconnecting live edge")
                    liveStatusLabel = "🔄 Fast Recovery ${stallRecoveryCount}/3..."
                    updateOsdForCurrentChannel()
                    player.seekToDefaultPosition()
                    player.prepare()
                    player.playWhenReady = true
                    uiHandler.postDelayed(this, 3500L)
                } else {
                    liveStatusLabel = "⚠️ Slow Server / Stream Stalled"
                    updateOsdForCurrentChannel()
                }
            }
        }
    }

    // Safety guard so user is never permanently stuck on the DTH startup overlay
    private val dismissBootSafetyRunnable: Runnable = Runnable {
        if (hasRenderedVideoFrame) return@Runnable
        if (allChannels.isNotEmpty()) {
            liveStatusLabel = "⏳ Connecting..."
            updateOsdForCurrentChannel()
            showZappingOsd()
            dismissDthBootOverlay("PLAYER READY • CONNECTING")
        } else {
            dismissDthBootOverlay("READY TO ADD PLAYLIST")
        }
    }

    private val persistStateRunnable: Runnable = Runnable {
        if (allChannels.isEmpty() || currentChannelIndex !in allChannels.indices) return@Runnable
        val ch = allChannels[currentChannelIndex]
        getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE).edit()
            .putString("recent_ids", recentIds.joinToString("\n"))
            .putString("last_channel_id", ch.id)
            .putInt("last_channel_index", currentChannelIndex)
            .apply()
    }

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            uiHandler.post {
                val player = exoPlayer ?: return@post
                if (allChannels.isNotEmpty() &&
                    (player.playbackState == Player.STATE_IDLE || liveStatusLabel.startsWith("⚠️") || liveStatusLabel.startsWith("🔄"))
                ) {
                    playbackRetryCount = 0
                    stallRecoveryCount = 0
                    liveStatusLabel = "🔄 Network Restored..."
                    updateOsdForCurrentChannel()
                    player.seekToDefaultPosition()
                    player.prepare()
                    player.playWhenReady = true
                }
            }
        }

        override fun onLost(network: Network) {
            uiHandler.post {
                liveStatusLabel = "⚠️ Waiting for Network..."
                updateOsdForCurrentChannel()
            }
        }
    }

    private var allChannels: List<Channel> = listOf(
        Channel("1", 1, "Sports 18 HD (Test Stream)", "Sports", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"),
        Channel("2", 2, "Cinema Gold 4K Stream", "Movies", "https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8"),
        Channel("3", 3, "Bharat News 24x7 HD", "News", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"),
        Channel("4", 4, "Music Beats Dolby HD", "Music", "https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8")
    )
    private var allSequentialIndices: IntArray = IntArray(4) { it }
    private var channelsByCategory: Map<String, IntArray> = emptyMap()
    private var channelIndexById: Map<String, Int> = emptyMap()
    private var nonSequentialNumberMap: SparseIntArray = SparseIntArray(0)
    private var knownEpgAndChannelIds: Set<String> = emptySet()

    private var favoriteIds: MutableSet<String> = mutableSetOf("1")
    private var recentIds: MutableList<String> = mutableListOf()
    private var activeTab: String = "ALL"

    private var currentChannelIndex: Int = 0
    private var previousChannelIndex: Int = 0
    private var playbackRetryCount: Int = 0
    private var resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_FILL,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    )
    private var currentResizeIndex = 0
    private var sleepMinutes = 0
    private val sleepRunnable: Runnable = Runnable {
        exoPlayer?.pause()
        Toast.makeText(this, "Sleep Timer: Playback Paused", Toast.LENGTH_LONG).show()
    }

    private var numberInputBuffer: String = ""
    private val numberJumpRunnable: Runnable = Runnable {
        val targetNum = numberInputBuffer.toIntOrNull()
        numberInputBuffer = ""
        if (targetNum != null) {
            val idx = findChannelIndexByNumberFast(targetNum)
            if (idx != -1) {
                switchChannel(idx, immediatePlayback = true)
            } else {
                Toast.makeText(this, "Channel #$targetNum not found", Toast.LENGTH_SHORT).show()
                updateOsdForCurrentChannel()
            }
        }
    }

    private fun findChannelIndexByNumberFast(targetNum: Int): Int {
        val directIdx = targetNum - 1
        if (directIdx in allChannels.indices && allChannels[directIdx].number == targetNum) {
            return directIdx
        }
        val mapped = nonSequentialNumberMap.get(targetNum, -1)
        if (mapped != -1 && mapped in allChannels.indices) return mapped
        return allChannels.indexOfFirst { it.number == targetNum }
    }

    private val activePlayerListener = object : Player.Listener {
        override fun onRenderedFirstFrame() {
            val now = SystemClock.elapsedRealtime()
            if (firstVideoFrameMs == 0L) {
                firstVideoFrameMs = now - processStartElapsedMs
            }
            if (lastSwitchStartElapsedMs > 0L) {
                lastChannelSwitchMs = now - lastSwitchStartElapsedMs
            }
            hasRenderedVideoFrame = true
            if (isBootOverlayVisible) {
                dismissDthBootOverlay("READY TO WATCH")
            }
            exoPlayer?.let { updateLiveTelemetryBadge(it) }
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            val h = videoSize.height
            val w = videoSize.width
            if (h > 0 && w > 0) {
                liveResolutionLabel = when {
                    h >= 2160 || w >= 3840 -> "4K UHD"
                    h >= 1080 -> "1080p FHD"
                    h >= 720 -> "720p HD"
                    h >= 540 -> "576p HQ"
                    else -> "${h}p SD"
                }
                exoPlayer?.let { updateLiveTelemetryBadge(it) }
                updateOsdForCurrentChannel()
            }
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            val player = exoPlayer ?: return
            when (playbackState) {
                Player.STATE_BUFFERING -> {
                    liveStatusLabel = if (usingBackupStream) "⏳ Backup Buffering..." else "⏳ Buffering..."
                    updateOsdForCurrentChannel()
                    uiHandler.removeCallbacks(stallWatchdogRunnable)
                    uiHandler.postDelayed(stallWatchdogRunnable, 2500L)
                }
                Player.STATE_READY -> {
                    playbackRetryCount = 0
                    stallRecoveryCount = 0
                    uiHandler.removeCallbacks(stallWatchdogRunnable)
                    liveStatusLabel = if (usingBackupStream) "🟢 Live (Backup)" else "🟢 Live"
                    updateLiveTelemetryBadge(player)
                    updateOsdForCurrentChannel()

                    // Upgrade 1: Pre-warm 3-Slot Adjacent Players (N+1 & N-1) + 48MB SimpleCache + Top-10 Recents/Favs
                    if (allChannels.size > 1) {
                        uiHandler.removeCallbacks(prewarmAdjacentSlotsRunnable)
                        uiHandler.postDelayed(prewarmAdjacentSlotsRunnable, 350L)

                        val nextIdx = (currentChannelIndex + 1) % allChannels.size
                        val prevIdx = (currentChannelIndex - 1 + allChannels.size) % allChannels.size
                        StreamPreFetcher.scheduleAdjacentPrefetch(
                            this@PlayerActivity,
                            allChannels.getOrNull(nextIdx)?.streamUrl,
                            allChannels.getOrNull(prevIdx)?.streamUrl
                        )
                        val topUrls = ArrayList<String>(10)
                        for (id in recentIds) {
                            val idx = channelIndexById[id]
                            val u = if (idx != null) allChannels.getOrNull(idx)?.streamUrl else null
                            if (!u.isNullOrBlank() && u != currentPlayingStreamUrl && !topUrls.contains(u)) {
                                topUrls.add(u)
                                if (topUrls.size >= 10) break
                            }
                        }
                        if (topUrls.size < 10) {
                            for (id in favoriteIds) {
                                val idx = channelIndexById[id]
                                val u = if (idx != null) allChannels.getOrNull(idx)?.streamUrl else null
                                if (!u.isNullOrBlank() && u != currentPlayingStreamUrl && !topUrls.contains(u)) {
                                    topUrls.add(u)
                                    if (topUrls.size >= 10) break
                                }
                            }
                        }
                        StreamPreFetcher.scheduleTop10Warmup(this@PlayerActivity, topUrls)
                    }
                }
                Player.STATE_ENDED -> {
                    uiHandler.removeCallbacks(stallWatchdogRunnable)
                    liveStatusLabel = "🔄 Reconnecting..."
                    updateOsdForCurrentChannel()
                    uiHandler.removeCallbacks(retryPlaybackRunnable)
                    uiHandler.postDelayed(retryPlaybackRunnable, 900L)
                }
                Player.STATE_IDLE -> {
                    uiHandler.removeCallbacks(stallWatchdogRunnable)
                }
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            uiHandler.removeCallbacks(stallWatchdogRunnable)
            Log.w("StreamX", "Playback error (${error.errorCodeName}): ${error.message}")

            val activeChannel = allChannels.getOrNull(currentChannelIndex)
            if (activeChannel != null && !usingBackupStream && activeChannel.backupUrl.isNotBlank()) {
                usingBackupStream = true
                playbackRetryCount = 0
                liveStatusLabel = "⚡ Auto-Failover Backup..."
                updateOsdForCurrentChannel()
                playSpecificStreamUrl(activeChannel.backupUrl)
                return
            }

            if (playbackRetryCount >= 3) {
                liveStatusLabel = "⚠️ Stream Offline"
                updateOsdForCurrentChannel()
                if (isBootOverlayVisible) {
                    dismissDthBootOverlay("READY TO WATCH")
                }
                Toast.makeText(
                    this@PlayerActivity,
                    "Stream offline or unreachable. Try another channel or tap 🔄 Sync.",
                    Toast.LENGTH_LONG
                ).show()
                return
            }
            playbackRetryCount++
            val retryNum = playbackRetryCount
            val backoffMs = 1200L * retryNum
            liveStatusLabel = "🔄 Retry $retryNum/3..."
            updateOsdForCurrentChannel()
            uiHandler.removeCallbacks(retryPlaybackRunnable)
            uiHandler.postDelayed(retryPlaybackRunnable, backoffMs)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        processStartElapsedMs = SystemClock.elapsedRealtime()
        hasRenderedVideoFrame = false
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)

        dthBootOverlay = findViewById(R.id.dthBootOverlay)
        vSignalWaveOuter = findViewById(R.id.vSignalWaveOuter)
        vSignalWaveInner = findViewById(R.id.vSignalWaveInner)
        tvBootHeadline = findViewById(R.id.tvBootHeadline)
        tvBootStageStatus = findViewById(R.id.tvBootStageStatus)
        tvBootSubDetail = findViewById(R.id.tvBootSubDetail)
        bootProgressBar = findViewById(R.id.bootProgressBar)

        detectDeviceMemoryProfile()
        runCatching {
            NetworkClient.initLogoDiskCache(cacheDir)
            Glide.get(this).setMemoryCategory(MemoryCategory.HIGH)
        }

        startDthBootSignalAnimation()
        updateBootStage(8, "Starting StreamX v12.0 Apex...", "4GB Flagship 3-Slot Engine • Frame 1 Active")

        findViewById<Button>(R.id.btnProfiles).setOnClickListener { showProfilesDialog() }
        playerView = findViewById(R.id.media3PlayerView)
        playerView.keepScreenOn = true
        topControlBar = findViewById(R.id.topControlBar)
        leftChannelDrawer = findViewById(R.id.leftChannelDrawer)
        channelListRecycler = findViewById(R.id.channelListRecycler)
        tvEmptyDrawer = findViewById(R.id.tvEmptyDrawer)
        osdBanner = findViewById(R.id.zappingOsdContainer)
        tvChannelNumber = findViewById(R.id.tvChannelNumber)
        tvChannelName = findViewById(R.id.tvChannelName)
        tvChannelCategory = findViewById(R.id.tvChannelCategory)
        tvEpgNow = findViewById(R.id.tvEpgNow)
        tvActiveSectionBadge = findViewById(R.id.tvActiveSectionBadge)
        btnToggleFavorite = findViewById(R.id.btnToggleFavorite)
        btnRecallChannel = findViewById(R.id.btnRecallChannel)
        btnToggleDrawer = findViewById(R.id.btnToggleDrawer)
        tabAllChannels = findViewById(R.id.tabAllChannels)
        channelSearch = findViewById(R.id.channelSearch)
        categoryFilter = findViewById(R.id.categoryFilter)
        channelLogo = findViewById(R.id.channelLogo)

        channelAdapter = ChannelDrawerAdapter(
            channelProvider = { idx -> allChannels.getOrNull(idx) },
            isFavorite = { id -> favoriteIds.contains(id) },
            onChannelClick = { globalIdx -> switchChannel(globalIdx, immediatePlayback = true) },
            onChannelFocused = { globalIdx ->
                val focusedCh = allChannels.getOrNull(globalIdx)
                if (focusedCh != null && focusedCh.streamUrl != currentPlayingStreamUrl) {
                    StreamPreFetcher.scheduleFocusPrefetch(this@PlayerActivity, focusedCh.streamUrl)
                }
            }
        )
        val linearLm = LinearLayoutManager(this)
        channelListRecycler.layoutManager = linearLm
        channelListRecycler.setHasFixedSize(true)
        channelListRecycler.setItemViewCacheSize(16)
        channelListRecycler.recycledViewPool.setMaxRecycledViews(0, 24)
        channelListRecycler.itemAnimator = null
        channelListRecycler.adapter = channelAdapter

        channelListRecycler.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                if (dy <= 0) return
                val totalLoadedInAdapter = channelAdapter.itemCount
                if (totalLoadedInAdapter < fullFilteredIndices.size) {
                    val lastVisible = linearLm.findLastVisibleItemPosition()
                    if (lastVisible >= totalLoadedInAdapter - 30) {
                        currentPagedLimit = (currentPagedLimit + pageStepSize).coerceAtMost(fullFilteredIndices.size)
                        channelAdapter.submitIndices(
                            fullFilteredIndices.copyOfRange(0, currentPagedLimit),
                            currentChannelIndex,
                            null
                        )
                    }
                }
            }
        })

        setupUiListeners()

        window.decorView.post {
            firstUiFrameMs = SystemClock.elapsedRealtime() - processStartElapsedMs
            startStagedBootSequence()
        }
    }

    private fun detectDeviceMemoryProfile() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        if (am != null) {
            val memInfo = ActivityManager.MemoryInfo()
            am.getMemoryInfo(memInfo)
            totalDeviceRamMb = (memInfo.totalMem / (1024L * 1024L)).coerceAtLeast(1024L)
        }
        maxPlaylistLimit = 60_000
    }

    private fun startDthBootSignalAnimation() {
        val satellite = findViewById<View>(R.id.ivBootSatellite)
        satellite.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        satellitePulseAnimator = ObjectAnimator.ofPropertyValuesHolder(
            satellite,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 0.96f, 1.04f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 0.96f, 1.04f),
            PropertyValuesHolder.ofFloat(View.ALPHA, 0.88f, 1.0f)
        ).apply {
            duration = 2000L
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            start()
        }

        val scaleXOuter = PropertyValuesHolder.ofFloat(View.SCALE_X, 0.90f, 1.12f)
        val scaleYOuter = PropertyValuesHolder.ofFloat(View.SCALE_Y, 0.90f, 1.12f)
        val alphaOuter = PropertyValuesHolder.ofFloat(View.ALPHA, 0.75f, 0.20f)
        outerWaveAnimator = ObjectAnimator.ofPropertyValuesHolder(
            vSignalWaveOuter,
            scaleXOuter,
            scaleYOuter,
            alphaOuter
        ).apply {
            duration = 1400L
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.RESTART
            start()
        }

        val alphaInner = PropertyValuesHolder.ofFloat(View.ALPHA, 0.40f, 0.90f)
        innerWaveAnimator = ObjectAnimator.ofPropertyValuesHolder(
            vSignalWaveInner,
            alphaInner
        ).apply {
            duration = 1000L
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            start()
        }
    }

    private fun cancelBootAnimators() {
        outerWaveAnimator?.cancel()
        innerWaveAnimator?.cancel()
        satellitePulseAnimator?.cancel()
        outerWaveAnimator = null
        innerWaveAnimator = null
        satellitePulseAnimator = null
    }

    private fun updateBootStage(progress: Int, stageText: String, subDetail: String? = null) {
        if (!isBootOverlayVisible) return
        bootProgressBar.progress = progress.coerceIn(0, 100)
        tvBootStageStatus.text = stageText
        if (subDetail != null) {
            tvBootSubDetail.text = subDetail
        }
    }

    private fun dismissDthBootOverlay(finalMessage: String = "READY TO WATCH") {
        if (!isBootOverlayVisible) return
        isBootOverlayVisible = false
        uiHandler.removeCallbacks(dismissBootSafetyRunnable)
        bootReadyElapsedMs = SystemClock.elapsedRealtime() - processStartElapsedMs
        bootProgressBar.progress = 100
        tvBootHeadline.text = finalMessage
        tvBootStageStatus.text = "StreamX v12.0 Apex initialized • ${bootReadyElapsedMs}ms"
        cancelBootAnimators()
        dthBootOverlay.animate()
            .alpha(0f)
            .setDuration(180L)
            .withLayer()
            .withEndAction {
                dthBootOverlay.visibility = View.GONE
                dthBootOverlay.alpha = 1f
            }
            .start()
    }

    private fun isNetworkConnectedNow(): Boolean {
        val cm = connectivityManager ?: return true
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val net = cm.activeNetwork ?: return false
                val caps = cm.getNetworkCapabilities(net) ?: return false
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            } else {
                @Suppress("DEPRECATION")
                cm.activeNetworkInfo?.isConnected == true
            }
        } catch (_: Exception) {
            true
        }
    }

    private fun startStagedBootSequence() {
        uiHandler.postDelayed(dismissBootSafetyRunnable, 20_000L)

        lifecycleScope.launch {
            updateBootStage(
                15,
                "Loading saved settings...",
                "RAM Detected: ${totalDeviceRamMb}MB • Apex 4GB Flagship Mode"
            )
            val prefs = getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
            val bootSettings = withContext(Dispatchers.IO) {
                profileStore = ProfileStore(this@PlayerActivity)
                channelCache = ChannelCacheStore(this@PlayerActivity)
                epgCache = EpgCacheStore(this@PlayerActivity)
                StreamPreFetcher.getOrCreateSimpleCache(this@PlayerActivity)

                val favs = prefs.getStringSet("fav_ids", null)?.toHashSet() ?: hashSetOf("1")
                val recents = prefs.getString("recent_ids", "")
                    ?.lines()
                    ?.filter { it.isNotBlank() }
                    ?.take(20) ?: emptyList()
                val themeIdx = prefs.getInt("theme_index", 0)
                val bufId = prefs.getString("buffer_profile_id", null)
                val autoBoot = prefs.getBoolean("auto_boot_enabled", true)
                val autoResume = prefs.getBoolean("auto_resume_enabled", true)
                val savedEpgUrl = prefs.getString("last_epg_url", "") ?: ""
                val cachedEpg = epgCache.loadEpg()

                BootSettingsBundle(
                    favs = favs,
                    recents = recents,
                    themeIndex = themeIdx,
                    bufferProfile = BufferProfile.fromId(bufId),
                    autoBoot = autoBoot,
                    autoResume = autoResume,
                    savedEpgUrl = savedEpgUrl,
                    cachedEpg = cachedEpg
                )
            }

            favoriteIds.clear()
            favoriteIds.addAll(bootSettings.favs)
            recentIds.clear()
            recentIds.addAll(bootSettings.recents)
            activeBufferProfile = bootSettings.bufferProfile
            autoBootEnabled = bootSettings.autoBoot
            autoResumeEnabled = bootSettings.autoResume
            applyTheme(bootSettings.themeIndex)

            if (bootSettings.cachedEpg != null) {
                epgMap = bootSettings.cachedEpg.entries
            }

            updateBootStage(
                35,
                "Initializing 3-Slot Media3 4K Engine...",
                "Buffer: ${activeBufferProfile.label}"
            )
            initializeMedia3ProEngine()
            rebuildChannelIndicesSync(allChannels)

            val hasNet = isNetworkConnectedNow()
            if (!hasNet) {
                updateBootStage(
                    50,
                    "Network unavailable – Loading saved channels.",
                    "Offline Cache Mode Active"
                )
            } else {
                updateBootStage(
                    50,
                    "Checking Network Connection...",
                    "Network Connected • Restoring Playlist"
                )
            }

            val epgUrlToRefresh = bootSettings.savedEpgUrl.ifBlank { bootSettings.cachedEpg?.sourceUrl.orEmpty() }
            if (hasNet && epgUrlToRefresh.isNotBlank()) {
                val epgAge = System.currentTimeMillis() - (bootSettings.cachedEpg?.timestampMs ?: 0L)
                if (epgAge > EpgCacheStore.EPG_REFRESH_INTERVAL_MS) {
                    loadXmltvEpg(epgUrlToRefresh, silentBackground = true)
                }
            }

            updateBootStage(65, "Restoring Your Channels...", "Checking local instant cache")
            restoreSavedDataFromBoot(prefs, hasNet)
        }
    }

    private data class BootSettingsBundle(
        val favs: Set<String>,
        val recents: List<String>,
        val themeIndex: Int,
        val bufferProfile: BufferProfile,
        val autoBoot: Boolean,
        val autoResume: Boolean,
        val savedEpgUrl: String,
        val cachedEpg: CachedEpgData?
    )

    private fun setupUiListeners() {
        channelSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                searchQuery = s?.toString().orEmpty()
                renderDrawerList(debounceMs = 150L)
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        categoryFilter.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (suppressCategoryCallback) return
                selectedCategory = parent?.getItemAtPosition(position)?.toString() ?: "All categories"
                renderDrawerList()
            }
        }

        btnToggleDrawer.setOnClickListener {
            if (leftChannelDrawer.visibility == View.VISIBLE) {
                closeDrawerAndRestoreFocus()
            } else {
                openDrawerAndRequestFocus()
            }
        }
        tabAllChannels.setOnClickListener {
            activeTab = "ALL"
            tvActiveSectionBadge.text = "StreamX Media3 Pro • All Live TV (${allChannels.size})"
            renderDrawerList()
        }
        findViewById<Button>(R.id.tabFavorites).setOnClickListener {
            activeTab = "FAV"
            tvActiveSectionBadge.text = "StreamX Media3 Pro • ⭐ Favorites (${favoriteIds.size})"
            renderDrawerList()
        }
        findViewById<Button>(R.id.tabRecent).setOnClickListener {
            activeTab = "RECENT"
            tvActiveSectionBadge.text = "StreamX Media3 Pro • 🕒 Recent Watched"
            renderDrawerList()
        }

        findViewById<Button>(R.id.btnXtreamLogin).setOnClickListener { showXtreamLoginDialog() }
        findViewById<Button>(R.id.btnM3uLoad).setOnClickListener { showM3uLoadDialog() }
        findViewById<Button>(R.id.btnRefreshChannels).setOnClickListener { forceRefreshActivePlaylist() }
        findViewById<Button>(R.id.btnAudioQuality).setOnClickListener { showAudioAndQualityDialog() }
        findViewById<Button>(R.id.btnThemeToggle).setOnClickListener { showThemeAndPipDialog() }

        findViewById<Button>(R.id.btnZapUp).setOnClickListener { switchChannel(currentChannelIndex + 1, immediatePlayback = true) }
        findViewById<Button>(R.id.btnZapDown).setOnClickListener { switchChannel(currentChannelIndex - 1, immediatePlayback = true) }
        btnRecallChannel.setOnClickListener { recallPreviousChannel() }
        btnToggleFavorite.setOnClickListener { toggleCurrentChannelFavorite() }

        findViewById<Button>(R.id.btnEpg).setOnClickListener { showEpgUrlDialog() }

        val btnSleep = findViewById<Button>(R.id.btnSleepTimer)
        btnSleep.setOnLongClickListener { showEpgUrlDialog(); true }
        btnSleep.setOnClickListener {
            sleepMinutes = when (sleepMinutes) {
                0 -> 15
                15 -> 30
                30 -> 60
                60 -> 90
                else -> 0
            }
            uiHandler.removeCallbacks(sleepRunnable)
            if (sleepMinutes > 0) {
                uiHandler.postDelayed(sleepRunnable, sleepMinutes * 60 * 1000L)
                btnSleep.text = "🌙 Sleep: ${sleepMinutes}m"
                Toast.makeText(this, "Sleep Timer set for $sleepMinutes mins", Toast.LENGTH_SHORT).show()
            } else {
                btnSleep.text = "🌙 Sleep: OFF"
            }
        }

        val btnAspect = findViewById<Button>(R.id.btnAspectToggle)
        btnAspect.setOnClickListener {
            currentResizeIndex = (currentResizeIndex + 1) % resizeModes.size
            playerView.resizeMode = resizeModes[currentResizeIndex]
            btnAspect.text = when (currentResizeIndex) {
                0 -> "16:9 Fit"
                1 -> "Full Stretch"
                else -> "Cinema Zoom"
            }
        }

        playerView.setOnClickListener {
            if (leftChannelDrawer.visibility == View.VISIBLE) {
                closeDrawerAndRestoreFocus()
            } else {
                showZappingOsd()
            }
        }
    }

    // Upgrade 4: Live Mini-TV Floating Mode (smoothly shrinks PlayerView into corner PiP window on GPU)
    private fun enterMiniTvFloatingMode() {
        if (isMiniTvFloating) return
        isMiniTvFloating = true
        val w = playerView.width.takeIf { it > 0 } ?: 1280
        val h = playerView.height.takeIf { it > 0 } ?: 720
        playerView.animate()
            .scaleX(0.62f)
            .scaleY(0.62f)
            .translationX(w * 0.16f)
            .translationY(-h * 0.08f)
            .setDuration(220L)
            .withLayer()
            .start()
    }

    private fun exitMiniTvFloatingMode() {
        if (!isMiniTvFloating) return
        isMiniTvFloating = false
        playerView.animate()
            .scaleX(1.0f)
            .scaleY(1.0f)
            .translationX(0f)
            .translationY(0f)
            .setDuration(200L)
            .withLayer()
            .start()
    }

    private fun openDrawerAndRequestFocus() {
        leftChannelDrawer.visibility = View.VISIBLE
        topControlBar.visibility = View.VISIBLE
        enterMiniTvFloatingMode()
        renderDrawerList(scrollToActive = true, requestFocusOnActive = true)
    }

    private fun closeDrawerAndRestoreFocus() {
        leftChannelDrawer.visibility = View.GONE
        exitMiniTvFloatingMode()
        playerView.requestFocus()
    }

    private fun cacheKeyFor(raw: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(raw.toByteArray(Charsets.UTF_8))
        return bytes.take(12).joinToString("") { "%02x".format(it) }
    }

    private fun rebuildChannelIndicesSync(channels: List<Channel>) {
        val seq = IntArray(channels.size) { it }
        val byId = HashMap<String, Int>(channels.size)
        val nonSeqNum = SparseIntArray()
        val byCatTemp = HashMap<String, ArrayList<Int>>(32)
        val epgIds = HashSet<String>(channels.size * 2)

        for (i in channels.indices) {
            val ch = channels[i]
            if (!byId.containsKey(ch.id)) byId[ch.id] = i
            if (ch.number != i + 1 && nonSeqNum.indexOfKey(ch.number) < 0) {
                nonSeqNum.put(ch.number, i)
            }
            byCatTemp.getOrPut(ch.category.lowercase(Locale.ROOT)) { ArrayList() }.add(i)
            epgIds.add(ch.id)
            if (ch.epgId.isNotEmpty()) epgIds.add(ch.epgId)
        }
        val byCatPrimitive = HashMap<String, IntArray>(byCatTemp.size)
        for ((k, list) in byCatTemp) {
            byCatPrimitive[k] = list.toIntArray()
        }
        allSequentialIndices = seq
        channelIndexById = byId
        nonSequentialNumberMap = nonSeqNum
        channelsByCategory = byCatPrimitive
        knownEpgAndChannelIds = epgIds
    }

    private suspend fun applyLoadedChannels(
        newChannels: List<Channel>,
        sectionTitle: String? = null,
        resumeLastWatched: Boolean = true,
        isPreliminaryBatch: Boolean = false
    ) {
        val prefs = getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
        val shouldResume = resumeLastWatched && autoResumeEnabled
        val savedLastId = if (shouldResume) prefs.getString("last_channel_id", null) else null
        val savedLastIndex = if (shouldResume) prefs.getInt("last_channel_index", 0) else 0

        if (!isPreliminaryBatch) {
            updateBootStage(78, "Preparing Channels (${newChannels.size} CH)...", "Building primitive index arrays")
        }

        val prepared = withContext(Dispatchers.Default) {
            val seq = IntArray(newChannels.size) { it }
            val byId = HashMap<String, Int>(newChannels.size)
            val nonSeqNum = SparseIntArray()
            val byCatTemp = HashMap<String, ArrayList<Int>>(128)
            val categorySet = LinkedHashSet<String>()
            val epgIds = HashSet<String>(newChannels.size.coerceAtMost(25000))

            for (i in newChannels.indices) {
                if (i % 2000 == 0) ensureActive()
                val ch = newChannels[i]
                if (!byId.containsKey(ch.id)) byId[ch.id] = i
                if (ch.number != i + 1 && nonSeqNum.indexOfKey(ch.number) < 0) {
                    nonSeqNum.put(ch.number, i)
                }
                if (ch.category.isNotBlank()) {
                    categorySet.add(ch.category)
                    byCatTemp.getOrPut(ch.category.lowercase(Locale.ROOT)) { ArrayList() }.add(i)
                }
                if (epgIds.size < 35000) {
                    epgIds.add(ch.id)
                    if (ch.epgId.isNotEmpty()) epgIds.add(ch.epgId)
                }
            }
            val byCatPrimitive = HashMap<String, IntArray>(byCatTemp.size)
            for ((k, list) in byCatTemp) {
                byCatPrimitive[k] = list.toIntArray()
            }
            val categories = ArrayList<String>(categorySet.size + 1).apply {
                add("All categories")
                addAll(categorySet.sorted())
            }
            val targetIdx = if (shouldResume) {
                (if (!savedLastId.isNullOrBlank()) byId[savedLastId] else null)
                    ?: savedLastIndex.takeIf { it in newChannels.indices }
                    ?: 0
            } else {
                0
            }
            PreparedChannelData(seq, byId, nonSeqNum, byCatPrimitive, categories, epgIds, targetIdx)
        }

        allChannels = newChannels
        allSequentialIndices = prepared.seq
        channelIndexById = prepared.byId
        nonSequentialNumberMap = prepared.nonSeqNum
        channelsByCategory = prepared.byCat
        knownEpgAndChannelIds = prepared.epgIds

        suppressCategoryCallback = true
        selectedCategory = "All categories"
        categoryFilter.adapter = ArrayAdapter(
            this@PlayerActivity,
            android.R.layout.simple_spinner_dropdown_item,
            prepared.categories
        )
        categoryFilter.setSelection(0, false)
        suppressCategoryCallback = false

        if (sectionTitle != null) {
            tvActiveSectionBadge.text = sectionTitle
        }

        if (!isPreliminaryBatch || currentPlayingStreamUrl.isEmpty()) {
            previousChannelIndex = prepared.startIndex
            updateBootStage(90, "Preparing Live Television...", "Starting Channel #${prepared.startIndex + 1}")
            switchChannel(prepared.startIndex, immediatePlayback = true)
        }

        if (leftChannelDrawer.visibility == View.VISIBLE) {
            renderDrawerList(scrollToActive = true)
        }
    }

    private data class PreparedChannelData(
        val seq: IntArray,
        val byId: Map<String, Int>,
        val nonSeqNum: SparseIntArray,
        val byCat: Map<String, IntArray>,
        val categories: List<String>,
        val epgIds: Set<String>,
        val startIndex: Int
    )

    // Upgrade 1, 2 & 3: Build Tunneled 4K 60fps ExoPlayer Slot with 60s Mega Buffer + 20s Live Rewind
    private fun createConfiguredPlayerSlot(isPrimaryActiveSlot: Boolean): ExoPlayer {
        val bp = activeBufferProfile
        val allocator = DefaultAllocator(true, 64 * 1024)
        if (isPrimaryActiveSlot) {
            sharedAllocator = allocator
        }

        val loadControlBuilder = DefaultLoadControl.Builder()
            .setAllocator(allocator)
        if (isPrimaryActiveSlot) {
            loadControlBuilder
                .setBufferDurationsMs(bp.minBufferMs, bp.maxBufferMs, bp.playBufferMs, bp.rebufferMs)
                .setTargetBufferBytes(bp.targetBytes)
                // Upgrade 2: 20-second instant live match rewind in RAM on 4GB Apex profile
                .setBackBuffer(bp.backBufferMs, bp.backBufferMs > 0)
                .setPrioritizeTimeOverSizeThresholds(bp.prioritizeTimeOverSize)
        } else {
            // Secondary prewarm slots use fast-start forward buffer with zero back-buffer overhead
            loadControlBuilder
                .setBufferDurationsMs(4000, 10000, 150, 500)
                .setTargetBufferBytes(4 * 1024 * 1024)
                .setBackBuffer(0, false)
                .setPrioritizeTimeOverSizeThresholds(false)
        }

        val renderersFactory = DefaultRenderersFactory(this)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            .setEnableDecoderFallback(true)

        val cachedFactory = cacheDataSourceFactory ?: run {
            val okHttpDataSourceFactory = OkHttpDataSource.Factory(NetworkClient.streamClient)
                .setUserAgent("StreamX-Media3Pro/12.0-Apex-4GB (AndroidTV)")
            StreamPreFetcher.buildCacheDataSourceFactory(this, okHttpDataSourceFactory).also {
                cacheDataSourceFactory = it
            }
        }
        if (hlsChunklessFactory == null) {
            hlsChunklessFactory = HlsMediaSource.Factory(cachedFactory)
                .setAllowChunklessPreparation(true)
        }

        // Upgrade 3: Unlock Full 4K 60FPS Tunneled Playback via DefaultTrackSelector
        val trackSelector = DefaultTrackSelector(this).apply {
            setParameters(
                buildUponParameters()
                    .setTunnelingEnabled(isPrimaryActiveSlot)
                    .setPreferredAudioLanguages("hi", "hin", "en", "eng")
                    .clearVideoSizeConstraints()
                    .setMaxVideoBitrate(Int.MAX_VALUE)
            )
        }

        return ExoPlayer.Builder(this, renderersFactory)
            .setTrackSelector(trackSelector)
            .setLoadControl(loadControlBuilder.build())
            .setSeekBackIncrementMs(10_000L)
            .setSeekForwardIncrementMs(10_000L)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                isPrimaryActiveSlot
            )
            .setHandleAudioBecomingNoisy(true)
            .setMediaSourceFactory(DefaultMediaSourceFactory(cachedFactory))
            .build()
            .also { player ->
                player.videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT
                // Upgrade 3: Seamless Display Refresh-Rate Sync for 24fps Cinema & 50/60fps Sports
                player.videoChangeFrameRateStrategy = C.VIDEO_CHANGE_FRAME_RATE_STRATEGY_ONLY_IF_SEAMLESS
                if (!isPrimaryActiveSlot) {
                    player.volume = 0f
                    player.playWhenReady = false
                }
            }
    }

    private fun initializeMedia3ProEngine(recreateIfPresent: Boolean = false) {
        if (exoPlayer != null && !recreateIfPresent) return
        val previousUrl = currentPlayingStreamUrl
        if (recreateIfPresent) {
            releaseAllPlayerSlots()
            currentPlayingStreamUrl = ""
        }

        exoPlayer = createConfiguredPlayerSlot(isPrimaryActiveSlot = true).also { player ->
            playerView.player = player
            playerView.resizeMode = resizeModes[currentResizeIndex]
            player.addListener(activePlayerListener)
        }

        if (previousUrl.isNotEmpty() && allChannels.isNotEmpty()) {
            startPlaybackForCurrentChannel(forceReload = true)
        }
    }

    // Upgrade 1: Pre-warm Next (N+1) and Previous (N-1) Channels on Secondary ExoPlayer Slots with Codec Safety Guards
    private fun prewarmAdjacentPlayerSlotsSafe() {
        if (allChannels.size <= 1) return
        val nextIdx = (currentChannelIndex + 1) % allChannels.size
        val prevIdx = (currentChannelIndex - 1 + allChannels.size) % allChannels.size
        val nextUrl = allChannels.getOrNull(nextIdx)?.streamUrl.orEmpty()
        val prevUrl = allChannels.getOrNull(prevIdx)?.streamUrl.orEmpty()

        // Slot 2: NextPrewarmPlayer (N+1)
        if (nextUrl.isNotBlank() && nextUrl != currentPlayingStreamUrl && nextPrewarmUrl != nextUrl) {
            try {
                val pNext = nextPrewarmPlayer ?: createConfiguredPlayerSlot(isPrimaryActiveSlot = false).also {
                    nextPrewarmPlayer = it
                }
                pNext.volume = 0f
                pNext.playWhenReady = false
                bindUrlToPlayer(pNext, nextUrl)
                pNext.prepare()
                nextPrewarmUrl = nextUrl
            } catch (e: Exception) {
                Log.w("StreamX", "NextPrewarmPlayer guard caught exception: ${e.message}")
                runCatching { nextPrewarmPlayer?.release() }
                nextPrewarmPlayer = null
                nextPrewarmUrl = ""
            }
        }

        // Slot 3: PrevPrewarmPlayer (N-1) — falls back gracefully to 2 slots if chipset limits codec instances
        if (allowThirdCodecSlot && prevUrl.isNotBlank() && prevUrl != currentPlayingStreamUrl && prevUrl != nextUrl && prevPrewarmUrl != prevUrl) {
            try {
                val pPrev = prevPrewarmPlayer ?: createConfiguredPlayerSlot(isPrimaryActiveSlot = false).also {
                    prevPrewarmPlayer = it
                }
                pPrev.volume = 0f
                pPrev.playWhenReady = false
                bindUrlToPlayer(pPrev, prevUrl)
                pPrev.prepare()
                prevPrewarmUrl = prevUrl
            } catch (e: Exception) {
                Log.w("StreamX", "Chipset 2-codec limit detected; gracefully using 2-Slot Dual Player mode: ${e.message}")
                allowThirdCodecSlot = false
                runCatching { prevPrewarmPlayer?.release() }
                prevPrewarmPlayer = null
                prevPrewarmUrl = ""
            }
        }
    }

    private fun bindUrlToPlayer(player: ExoPlayer, targetUrl: String) {
        val mediaItem = MediaItem.Builder()
            .setUri(targetUrl)
            .setLiveConfiguration(
                MediaItem.LiveConfiguration.Builder()
                    .setMaxPlaybackSpeed(1.02f)
                    .build()
            )
            .build()
        val hlsFactory = hlsChunklessFactory
        if (hlsFactory != null && targetUrl.contains(".m3u8", ignoreCase = true)) {
            player.setMediaSource(hlsFactory.createMediaSource(mediaItem), true)
        } else {
            player.setMediaItem(mediaItem, true)
        }
    }

    private fun releaseAllPlayerSlots() {
        uiHandler.removeCallbacks(prewarmAdjacentSlotsRunnable)
        playerView.player = null
        runCatching {
            exoPlayer?.removeListener(activePlayerListener)
            exoPlayer?.release()
        }
        runCatching { nextPrewarmPlayer?.release() }
        runCatching { prevPrewarmPlayer?.release() }
        exoPlayer = null
        nextPrewarmPlayer = null
        prevPrewarmPlayer = null
        nextPrewarmUrl = ""
        prevPrewarmUrl = ""
    }

    private fun updateLiveTelemetryBadge(player: ExoPlayer) {
        val vf = player.videoFormat ?: return
        val parts = ArrayList<String>(2)
        if (vf.frameRate > 0f) {
            parts.add("${vf.frameRate.toInt()}fps")
        }
        if (vf.bitrate > 0) {
            val mbps = vf.bitrate / 1_000_000.0
            parts.add(String.format(Locale.US, "%.1fMbps", mbps))
        }
        liveTelemetryDetail = parts.joinToString(" • ")
    }

    private fun recallPreviousChannel() {
        if (allChannels.isEmpty()) return
        if (previousChannelIndex != currentChannelIndex && previousChannelIndex in allChannels.indices) {
            val target = previousChannelIndex
            Toast.makeText(this, "🔙 Recall: ${allChannels[target].name}", Toast.LENGTH_SHORT).show()
            switchChannel(target, immediatePlayback = true)
        } else if (recentIds.size >= 2) {
            val prevId = recentIds[1]
            val idx = channelIndexById[prevId]
            if (idx != null && idx != currentChannelIndex) {
                Toast.makeText(this, "🔙 Recall: ${allChannels[idx].name}", Toast.LENGTH_SHORT).show()
                switchChannel(idx, immediatePlayback = true)
            }
        } else {
            Toast.makeText(this, "No previous channel yet", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showAudioAndQualityDialog() {
        val player = exoPlayer ?: return
        val options = mutableListOf<String>()
        val actions = mutableListOf<() -> Unit>()

        // 1. Live Edge Sync & 20s RAM Timeshift Rewind Controls (Upgrade 2)
        options.add("⚡ Sync to Live Broadcast Edge (Zero Delay)")
        actions.add {
            player.seekToDefaultPosition()
            player.prepare()
            player.playWhenReady = true
            Toast.makeText(this, "⚡ Synced to real-time live edge!", Toast.LENGTH_SHORT).show()
        }

        options.add("⏪ Live Rewind -10s (20s RAM Back-Buffer)")
        actions.add {
            player.seekBack()
            Toast.makeText(this, "⏪ Rewound 10s in RAM buffer", Toast.LENGTH_SHORT).show()
        }

        options.add("⏩ Live Fast-Forward +10s")
        actions.add {
            player.seekForward()
            Toast.makeText(this, "⏩ Fast-forwarded +10s", Toast.LENGTH_SHORT).show()
        }

        // 2. Adaptive Buffer Profile Selector
        options.add("⚙️ Buffer Profile: ${activeBufferProfile.label}")
        actions.add {
            showBufferProfileDialog()
        }

        // 3. Video Quality Presets (Full 4K 60fps Unlocked by default)
        val qualities = listOf(
            "📺 Video Quality: Auto (Full 4K 60FPS / HDR Unlocked)" to null,
            "🌟 Video Quality: 4K UHD (3840x2160)" to (3840 to 2160),
            "🎬 Video Quality: 1080p Full HD" to (1920 to 1080),
            "📺 Video Quality: 720p HD" to (1280 to 720),
            "📱 Video Quality: 480p SD (Data Saver)" to (854 to 480)
        )
        for ((label, size) in qualities) {
            val activeMark = if (label.contains(selectedQualityLabel)) "✅ " else ""
            options.add("$activeMark$label")
            actions.add {
                val builder = player.trackSelectionParameters.buildUpon()
                if (size == null) {
                    builder.clearVideoSizeConstraints().setMaxVideoBitrate(Int.MAX_VALUE)
                    selectedQualityLabel = "Auto"
                } else {
                    builder.setMaxVideoSize(size.first, size.second)
                    selectedQualityLabel = if (size.second == 2160) "4K" else "${size.second}p"
                }
                player.trackSelectionParameters = builder.build()
                Toast.makeText(this, "Video Quality set to $selectedQualityLabel", Toast.LENGTH_SHORT).show()
            }
        }

        // 4. Multi-Audio Language Tracks from Stream (with Per-Channel Memory)
        val tracks: Tracks = player.currentTracks
        var audioIndex = 1
        val currentChId = allChannels.getOrNull(currentChannelIndex)?.id
        for (group in tracks.groups) {
            if (group.type == C.TRACK_TYPE_AUDIO && group.isSupported) {
                for (i in 0 until group.length) {
                    val format = group.getTrackFormat(i)
                    val rawLang = format.language
                    val lang = rawLang?.let { Locale(it).displayLanguage }?.ifBlank { null } ?: "Audio $audioIndex"
                    val label = format.label?.takeIf { it.isNotBlank() } ?: ""
                    val chCount = if (format.channelCount > 0) "${format.channelCount}ch" else ""
                    val selected = if (group.isTrackSelected(i)) "✅ " else ""
                    val title = "${selected}🔊 Audio Track $audioIndex: $lang $label $chCount".trim()
                    val trackGroup = group.mediaTrackGroup
                    val trackIdx = i
                    options.add(title)
                    actions.add {
                        player.trackSelectionParameters = player.trackSelectionParameters
                            .buildUpon()
                            .setOverrideForType(TrackSelectionOverride(trackGroup, trackIdx))
                            .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false)
                            .build()
                        if (!currentChId.isNullOrBlank() && !rawLang.isNullOrBlank()) {
                            profileStore.setPreferredAudioLanguage(currentChId, rawLang)
                        }
                        Toast.makeText(this, "Switched to $lang $label (Saved for channel)", Toast.LENGTH_SHORT).show()
                    }
                    audioIndex++
                }
            }
        }

        // 5. Subtitles Toggle
        val subStatus = if (subtitlesEnabled) "ON ✅" else "OFF"
        options.add("💬 Subtitles / Closed Captions: $subStatus")
        actions.add {
            subtitlesEnabled = !subtitlesEnabled
            player.trackSelectionParameters = player.trackSelectionParameters
                .buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !subtitlesEnabled)
                .build()
            Toast.makeText(
                this,
                if (subtitlesEnabled) "Subtitles Enabled" else "Subtitles Disabled",
                Toast.LENGTH_SHORT
            ).show()
        }

        AlertDialog.Builder(this)
            .setTitle("🔊 Audio, 4K 60FPS & 60s Mega Buffer")
            .setItems(options.toTypedArray()) { _, which ->
                actions.getOrNull(which)?.invoke()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showBufferProfileDialog() {
        val labels = BufferProfile.values().map { p ->
            "${if (p == activeBufferProfile) "● " else "○ "}${p.label}"
        }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("⚙️ 4GB Apex Buffer & Live Rewind Profile")
            .setItems(labels) { _, which ->
                val chosen = BufferProfile.values()[which]
                if (chosen != activeBufferProfile) {
                    activeBufferProfile = chosen
                    getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
                        .edit()
                        .putString("buffer_profile_id", chosen.id)
                        .apply()
                    initializeMedia3ProEngine(recreateIfPresent = true)
                    Toast.makeText(this, "Buffer Profile: ${chosen.label}", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Back", null)
            .show()
    }

    private fun showThemeAndPipDialog() {
        val items = mutableListOf<String>()
        themes.forEachIndexed { idx, t ->
            val mark = if (idx == currentThemeIndex) "● " else "○ "
            items.add("${mark}🎨 Theme: ${t.name}")
        }
        items.add("🚀 Auto-Start on TV Boot: ${if (autoBootEnabled) "ON ✅" else "OFF"}")
        items.add("▶️ Auto-Resume Last Channel: ${if (autoResumeEnabled) "ON ✅" else "OFF"}")
        val hasPin = profileStore.getParentalPin().length == 4
        items.add("🔒 Parental PIN Lock: ${if (hasPin) "ENABLED ✅" else "OFF"}")
        items.add("📊 4GB Apex Performance & 3-Slot Engine Monitor")
        items.add("🖼️ Toggle Floating Mini-TV Mode")
        items.add("📱 Enter System Picture-in-Picture (PiP)")
        items.add("🗑️ Clear Offline Channel, EPG & 48MB Zap Cache")

        AlertDialog.Builder(this)
            .setTitle("🎨 TV Themes, PiP & 4GB Apex Diagnostics")
            .setItems(items.toTypedArray()) { _, which ->
                when {
                    which in themes.indices -> {
                        applyTheme(which)
                        getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
                            .edit()
                            .putInt("theme_index", which)
                            .apply()
                        Toast.makeText(this, "Theme applied: ${themes[which].name}", Toast.LENGTH_SHORT).show()
                    }
                    which == themes.size -> toggleAutoBootSetting()
                    which == themes.size + 1 -> toggleAutoResumeSetting()
                    which == themes.size + 2 -> showParentalPinSettingsDialog()
                    which == themes.size + 3 -> showPerformanceMonitorDialog()
                    which == themes.size + 4 -> {
                        if (isMiniTvFloating) exitMiniTvFloatingMode() else enterMiniTvFloatingMode()
                    }
                    which == themes.size + 5 -> enterPipModeSafe()
                    which == themes.size + 6 -> {
                        lifecycleScope.launch {
                            channelCache.clearAllCaches()
                            epgCache.clear()
                            StreamPreFetcher.trimIdleCacheOnLowMemory()
                            Toast.makeText(
                                this@PlayerActivity,
                                "Channel, EPG & 48MB Zap caches cleared! Tap 🔄 Sync to reload.",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showParentalPinSettingsDialog() {
        val currentPin = profileStore.getParentalPin()
        val options = arrayOf(
            if (currentPin.length == 4) "🔑 Change 4-Digit Parental PIN" else "🔑 Set 4-Digit Parental PIN",
            "📂 Lock / Unlock Current Category (${allChannels.getOrNull(currentChannelIndex)?.category ?: "General"})",
            "❌ Disable Parental PIN Lock"
        )
        AlertDialog.Builder(this)
            .setTitle("🔒 4-Digit Parental PIN Lock")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        val input = EditText(this).apply {
                            hint = "Enter 4-digit PIN (e.g. 1234)"
                            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
                        }
                        AlertDialog.Builder(this)
                            .setTitle("Set 4-Digit Parental PIN")
                            .setView(input)
                            .setPositiveButton("Save PIN") { _, _ ->
                                val pin = input.text.toString().trim()
                                if (pin.length == 4 && pin.all { it.isDigit() }) {
                                    profileStore.setParentalPin(pin)
                                    unlockedSessionCategories.clear()
                                    Toast.makeText(this, "🔒 4-Digit Parental PIN Enabled!", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(this, "Please enter exactly 4 digits", Toast.LENGTH_SHORT).show()
                                }
                            }
                            .setNegativeButton("Cancel", null)
                            .show()
                    }
                    1 -> {
                        val cat = allChannels.getOrNull(currentChannelIndex)?.category ?: "General"
                        val locked = profileStore.toggleCategoryLock(cat)
                        Toast.makeText(
                            this,
                            if (locked) "🔒 Category '$cat' Locked" else "🔓 Category '$cat' Unlocked",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    2 -> {
                        profileStore.setParentalPin("")
                        unlockedSessionCategories.clear()
                        Toast.makeText(this, "🔓 Parental PIN Lock Disabled", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun promptParentalPinToUnlock(category: String, onUnlocked: () -> Unit) {
        val savedPin = profileStore.getParentalPin()
        val input = EditText(this).apply {
            hint = "Enter 4-digit PIN"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        AlertDialog.Builder(this)
            .setTitle("🔒 Locked Category: $category")
            .setMessage("Enter your 4-digit Parental PIN to watch channels in '$category':")
            .setView(input)
            .setPositiveButton("Unlock") { _, _ ->
                if (input.text.toString().trim() == savedPin) {
                    unlockedSessionCategories.add(category.lowercase(Locale.ROOT))
                    onUnlocked()
                } else {
                    Toast.makeText(this, "❌ Incorrect Parental PIN", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun toggleAutoBootSetting() {
        autoBootEnabled = !autoBootEnabled
        getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
            .edit()
            .putBoolean("auto_boot_enabled", autoBootEnabled)
            .apply()
        runCatching {
            val comp = ComponentName(this, BootReceiver::class.java)
            val newState = if (autoBootEnabled) {
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED
            } else {
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED
            }
            packageManager.setComponentEnabledSetting(comp, newState, PackageManager.DONT_KILL_APP)
        }
        Toast.makeText(
            this,
            "🚀 Auto-Start on TV Boot: ${if (autoBootEnabled) "ENABLED" else "DISABLED"}",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun toggleAutoResumeSetting() {
        autoResumeEnabled = !autoResumeEnabled
        getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
            .edit()
            .putBoolean("auto_resume_enabled", autoResumeEnabled)
            .apply()
        Toast.makeText(
            this,
            "▶️ Auto-Resume Last Channel: ${if (autoResumeEnabled) "ENABLED" else "DISABLED"}",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun showPerformanceMonitorDialog() {
        val rt = Runtime.getRuntime()
        val usedHeapMb = (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024)
        val maxHeapMb = rt.maxMemory() / (1024 * 1024)
        val nativeHeapMb = Debug.getNativeHeapAllocatedSize() / (1024 * 1024)
        val chCacheKb = channelCache.totalCacheSizeBytes() / 1024
        val epgCacheKb = epgCache.cacheSizeBytes() / 1024
        val zapCacheKb = StreamPreFetcher.cacheUsedBytes() / 1024
        val activeSlots = 1 + (if (nextPrewarmPlayer != null) 1 else 0) + (if (prevPrewarmPlayer != null) 1 else 0)

        val report = buildString {
            appendLine("• Edition: v12.0 Apex 4GB Flagship Edition")
            appendLine("• Device RAM: ${totalDeviceRamMb} MB (4K 60fps Tunneled Mode)")
            appendLine("• Multi-Decoder Slots Active: $activeSlots / 3 (Active + N+1 + N-1)")
            appendLine("• JVM Heap Used: $usedHeapMb MB / $maxHeapMb MB")
            appendLine("• Native Heap Allocated: $nativeHeapMb MB")
            appendLine("• Buffer Profile: ${activeBufferProfile.label}")
            appendLine("• Logo Cache: ARGB_8888 256x256 (36MB RAM LRU + 100MB Disk)")
            appendLine("• Network Pool: 20 Idle Conns (10m TTL) • 16/6 Dispatcher")
            appendLine("• Boot UI Frame 1: ${firstUiFrameMs} ms | Boot Ready: ${bootReadyElapsedMs} ms")
            appendLine("• Last Channel Switch Latency: ${if (lastChannelSwitchMs > 0) "${lastChannelSwitchMs} ms" else "N/A"}")
            appendLine("• Active Channels Loaded: ${allChannels.size}")
            appendLine("• Disk Cache: ${chCacheKb} KB (CH) + ${epgCacheKb} KB (EPG) + ${zapCacheKb} KB (48MB SimpleCache)")
        }

        AlertDialog.Builder(this)
            .setTitle("📊 StreamX v12.0 Apex 4GB Flagship Monitor")
            .setMessage(report)
            .setPositiveButton("Trim Caches") { _, _ ->
                StreamPreFetcher.trimIdleCacheOnLowMemory()
                sharedAllocator?.trim()
                runCatching { Glide.get(this).clearMemory() }
                Toast.makeText(this, "Idle caches trimmed", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun applyTheme(index: Int) {
        currentThemeIndex = index.coerceIn(themes.indices)
        val palette = themes[currentThemeIndex]
        val accentColor = Color.parseColor(palette.accentHex)
        val badgeTextColor = Color.parseColor(palette.badgeTextHex)
        val statusColor = Color.parseColor(palette.statusHex)

        tvChannelNumber.setTextColor(badgeTextColor)
        tvChannelCategory.setTextColor(statusColor)
        btnToggleDrawer.setTextColor(badgeTextColor)
        tabAllChannels.backgroundTintList = ColorStateList.valueOf(accentColor)
        channelAdapter.setAccentColor(accentColor)
    }

    private fun enterPipModeSafe() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val params = PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .build()
                enterPictureInPictureMode(params)
            } catch (e: Exception) {
                Log.w("StreamX", "PiP not supported: ${e.message}")
            }
        }
    }

    // Upgrade 4: Automatically enter Android TV System PiP when Home button is pressed during active playback
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && exoPlayer?.isPlaying == true) {
            enterPipModeSafe()
        }
    }

    private fun forceRefreshActivePlaylist() {
        val creds = activeXtreamCreds
        when {
            activeSourceType == ProfileType.XTREAM && creds != null -> {
                Toast.makeText(this, "🔄 Syncing fresh channels from Xtream Server...", Toast.LENGTH_SHORT).show()
                loadXtreamChannels(creds, forceNetworkRefresh = true)
            }
            activeSourceType == ProfileType.M3U && activeM3uInput.isNotBlank() -> {
                Toast.makeText(this, "🔄 Syncing fresh M3U playlist...", Toast.LENGTH_SHORT).show()
                loadM3uFromInput(activeM3uInput, activeM3uLabel, forceNetworkRefresh = true)
            }
            else -> {
                Toast.makeText(this, "Connect an Xtream or M3U account first to sync", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun toggleCurrentChannelFavorite() {
        if (allChannels.isEmpty()) return
        val ch = allChannels[currentChannelIndex]
        if (favoriteIds.contains(ch.id)) {
            favoriteIds.remove(ch.id)
            Toast.makeText(this, "Removed from ⭐ Favorites", Toast.LENGTH_SHORT).show()
        } else {
            favoriteIds.add(ch.id)
            Toast.makeText(this, "Added to ⭐ Favorites!", Toast.LENGTH_SHORT).show()
        }
        getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
            .edit()
            .putStringSet("fav_ids", HashSet(favoriteIds))
            .apply()
        updateFavButtonUi(ch.id)
        if (leftChannelDrawer.visibility == View.VISIBLE) {
            if (activeTab == "FAV") {
                renderDrawerList()
            } else {
                channelAdapter.notifyFavoriteChanged(currentChannelIndex)
            }
        }
    }

    private fun updateFavButtonUi(channelId: String) {
        val isFav = favoriteIds.contains(channelId)
        btnToggleFavorite.text = if (isFav) "★" else "☆"
    }

    private fun renderDrawerList(
        debounceMs: Long = 0L,
        scrollToActive: Boolean = false,
        requestFocusOnActive: Boolean = false
    ) {
        filterJob?.cancel()
        filterJob = lifecycleScope.launch {
            if (debounceMs > 0L) {
                delay(debounceMs)
            }
            val snapshotChannels = allChannels
            val snapshotSeq = allSequentialIndices
            val snapshotByCategory = channelsByCategory
            val snapshotFavs = HashSet(favoriteIds)
            val snapshotRecents = ArrayList(recentIds)
            val snapshotById = channelIndexById
            val tab = activeTab
            val query = searchQuery.trim()
            val category = selectedCategory
            val activeIdx = currentChannelIndex
            val oldIndices = channelAdapter.currentIndices()

            val (filteredAll, pagedSlice, diffResult) = withContext(Dispatchers.Default) {
                val matchAllCat = category == "All categories" || category.isBlank()
                val baseIndices: IntArray = when (tab) {
                    "FAV" -> {
                        val temp = ArrayList<Int>(snapshotFavs.size)
                        for (i in snapshotChannels.indices) {
                            if (snapshotFavs.contains(snapshotChannels[i].id)) temp.add(i)
                        }
                        temp.toIntArray()
                    }
                    "RECENT" -> {
                        val temp = ArrayList<Int>(snapshotRecents.size)
                        for (id in snapshotRecents) {
                            val idx = snapshotById[id]
                            if (idx != null && idx in snapshotChannels.indices) temp.add(idx)
                        }
                        temp.toIntArray()
                    }
                    else -> {
                        if (matchAllCat) {
                            snapshotSeq
                        } else {
                            snapshotByCategory[category.lowercase(Locale.ROOT)] ?: IntArray(0)
                        }
                    }
                }

                val resultIndices: IntArray = if (query.isEmpty() && (tab == "ALL" || matchAllCat)) {
                    baseIndices
                } else {
                    val temp = ArrayList<Int>(256)
                    for (idx in baseIndices) {
                        if (idx !in snapshotChannels.indices) continue
                        val ch = snapshotChannels[idx]
                        val catMatches = (tab == "ALL") || matchAllCat || ch.category.equals(category, ignoreCase = true)
                        val queryMatches = query.isEmpty() ||
                            ch.name.contains(query, ignoreCase = true) ||
                            ch.category.contains(query, ignoreCase = true)
                        if (catMatches && queryMatches) {
                            temp.add(idx)
                        }
                    }
                    temp.toIntArray()
                }

                val activePosInResult = if (scrollToActive) {
                    resultIndices.indexOfFirst { it == activeIdx }
                } else {
                    0
                }
                val requiredWindow = ((activePosInResult + 300).coerceAtLeast(pageStepSize))
                    .coerceAtMost(resultIndices.size)
                val slice = if (resultIndices.size > requiredWindow) {
                    resultIndices.copyOfRange(0, requiredWindow)
                } else {
                    resultIndices
                }

                val diff = if (oldIndices.isNotEmpty() && slice.isNotEmpty() &&
                    oldIndices.size <= 2500 && slice.size <= 2500 && oldIndices !== slice
                ) {
                    DiffUtil.calculateDiff(object : DiffUtil.Callback() {
                        override fun getOldListSize(): Int = oldIndices.size
                        override fun getNewListSize(): Int = slice.size
                        override fun areItemsTheSame(oldPos: Int, newPos: Int): Boolean =
                            oldIndices[oldPos] == slice[newPos]
                        override fun areContentsTheSame(oldPos: Int, newPos: Int): Boolean =
                            oldIndices[oldPos] == slice[newPos]
                    }, false)
                } else {
                    null
                }
                Triple(resultIndices, slice, diff)
            }

            fullFilteredIndices = filteredAll
            currentPagedLimit = pagedSlice.size

            if (pagedSlice.isEmpty()) {
                tvEmptyDrawer.text = if (tab == "FAV") {
                    "कोई Favorite चैनल नहीं है। ☆ बटन दबाकर जोड़ें।"
                } else {
                    "कोई चैनल नहीं मिला।"
                }
                tvEmptyDrawer.visibility = View.VISIBLE
                channelListRecycler.visibility = View.GONE
                channelAdapter.submitIndices(IntArray(0), activeIdx, null)
            } else {
                tvEmptyDrawer.visibility = View.GONE
                channelListRecycler.visibility = View.VISIBLE
                channelAdapter.submitIndices(pagedSlice, activeIdx, diffResult, isAscending = (tab != "RECENT"))
                if (scrollToActive) {
                    val pos = pagedSlice.indexOfFirst { it == activeIdx }.coerceAtLeast(0)
                    val lm = channelListRecycler.layoutManager as? LinearLayoutManager
                    lm?.scrollToPositionWithOffset(pos, 120)
                    if (requestFocusOnActive) {
                        channelListRecycler.post {
                            val holder = channelListRecycler.findViewHolderForAdapterPosition(pos)
                            if (holder != null) {
                                holder.itemView.requestFocus()
                            } else {
                                channelListRecycler.requestFocus()
                            }
                        }
                    }
                }
            }
        }
    }

    private fun importLocalM3uUri(uri: Uri) {
        loadChannelsJob?.cancel()
        loadChannelsJob = lifecycleScope.launch {
            val t0 = SystemClock.elapsedRealtime()
            tvActiveSectionBadge.text = "⏳ Importing playlist file..."
            runCatching {
                withContext(Dispatchers.IO) {
                    val cachedFile = File(filesDir, "local_playlist_${System.currentTimeMillis()}.m3u")
                    contentResolver.openInputStream(uri)?.use { input ->
                        cachedFile.outputStream().use { output ->
                            input.copyTo(output, bufferSize = 32768)
                        }
                    } ?: error("Cannot read selected file")
                    val channels = cachedFile.bufferedReader(Charsets.UTF_8).use { reader ->
                        M3uParser.parse(reader, maxChannels = maxPlaylistLimit, shouldCancel = { !isActive })
                    }
                    cachedFile to channels
                }
            }.onSuccess { (cachedFile, channels) ->
                lastPlaylistLoadDurationMs = SystemClock.elapsedRealtime() - t0
                if (channels.isNotEmpty()) {
                    val fileSource = "file://${cachedFile.absolutePath}"
                    val localProfile = PlaylistProfile(
                        name = "Local playlist (${channels.size} ch)",
                        type = ProfileType.M3U,
                        source = fileSource
                    )
                    profileStore.save(localProfile)
                    profileStore.setActive(localProfile.id)
                    activeSourceType = ProfileType.M3U
                    activeM3uInput = fileSource
                    activeM3uLabel = localProfile.name
                    val cKey = cacheKeyFor("m3u_$fileSource")
                    launch(Dispatchers.IO) {
                        channelCache.saveChannels(cKey, channels, maxLimit = maxPlaylistLimit)
                    }
                    applyLoadedChannels(channels, "StreamX Media3 Pro • ${localProfile.name}", resumeLastWatched = false)
                    Toast.makeText(this@PlayerActivity, "Imported & cached ${channels.size} channels", Toast.LENGTH_LONG).show()
                } else {
                    tvActiveSectionBadge.text = "StreamX Media3 Pro • All Live TV"
                    Toast.makeText(this@PlayerActivity, "No valid M3U channels found", Toast.LENGTH_LONG).show()
                }
            }.onFailure { e ->
                Log.w("StreamX", "Local M3U import failed", e)
                tvActiveSectionBadge.text = "StreamX Media3 Pro • All Live TV"
                Toast.makeText(this@PlayerActivity, "File import failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showEpgUrlDialog() {
        enterMiniTvFloatingMode()
        val prefs = getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
        val input = EditText(this).apply {
            hint = "XMLTV / EPG XML URL"
            setText(prefs.getString("last_epg_url", ""))
        }
        AlertDialog.Builder(this).setTitle("Load XMLTV EPG (Persistent Cache)")
            .setMessage("Add an XMLTV guide URL. Parsed Now/Next listings are cached locally and refreshed automatically.")
            .setView(input)
            .setOnDismissListener {
                if (leftChannelDrawer.visibility != View.VISIBLE) {
                    exitMiniTvFloatingMode()
                }
            }
            .setPositiveButton("Load & Cache Guide") { _, _ ->
                val url = input.text.toString().trim()
                if (url.isNotBlank()) {
                    prefs.edit().putString("last_epg_url", url).apply()
                    loadXmltvEpg(url, silentBackground = false)
                }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun loadXmltvEpg(url: String, silentBackground: Boolean = false) {
        epgLoadJob?.cancel()
        epgLoadJob = lifecycleScope.launch {
            if (!silentBackground) {
                Toast.makeText(this@PlayerActivity, "Loading EPG in background...", Toast.LENGTH_SHORT).show()
            }
            val filterIds = knownEpgAndChannelIds.takeIf { it.isNotEmpty() }
            runCatching {
                withContext(Dispatchers.IO) {
                    val request = Request.Builder().url(url).build()
                    NetworkClient.apiClient.newCall(request).execute().use { response ->
                        if (!response.isSuccessful) error("EPG HTTP ${response.code}")
                        val body = response.body ?: error("Empty EPG response")
                        BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8), 32768).use { reader ->
                            XmltvParser.parseNowNext(
                                reader = reader,
                                relevantChannelIds = filterIds,
                                shouldCancel = { !isActive }
                            )
                        }
                    }
                }
            }.onSuccess { parsedEpg ->
                if (parsedEpg.isNotEmpty()) {
                    epgMap = parsedEpg
                    launch(Dispatchers.IO) {
                        epgCache.saveEpg(url, parsedEpg)
                    }
                    if (allChannels.isNotEmpty()) updateOsdForCurrentChannel()
                }
                if (!silentBackground) {
                    Toast.makeText(this@PlayerActivity, "EPG cached: ${epgMap.size} channel entries", Toast.LENGTH_LONG).show()
                }
            }.onFailure { e ->
                Log.w("StreamX", "EPG load error", e)
                if (!silentBackground) {
                    Toast.makeText(this@PlayerActivity, "EPG error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun showProfilesDialog() {
        val profiles = profileStore.all()
        val labels = profiles.map { "${if (it.id == profileStore.activeId()) "● " else ""}${it.name}  (${it.type})" }.toMutableList()
        labels.add("＋ Add new playlist / account")
        labels.add("🔄 Force sync channels from server")
        labels.add("🔒 Parental PIN Lock Settings")
        labels.add("🚀 Auto-Start on TV Boot: ${if (autoBootEnabled) "ON ✅" else "OFF"}")
        labels.add("▶️ Auto-Resume Last Channel: ${if (autoResumeEnabled) "ON ✅" else "OFF"}")
        labels.add("✕ Delete a saved account")
        AlertDialog.Builder(this)
            .setTitle("Saved playlists & settings")
            .setItems(labels.toTypedArray()) { _, which ->
                when {
                    which == profiles.size -> showAddProfileDialog()
                    which == profiles.size + 1 -> forceRefreshActivePlaylist()
                    which == profiles.size + 2 -> showParentalPinSettingsDialog()
                    which == profiles.size + 3 -> toggleAutoBootSetting()
                    which == profiles.size + 4 -> toggleAutoResumeSetting()
                    which == profiles.size + 5 -> showDeleteProfileDialog()
                    which < profiles.size -> activateProfile(profiles[which])
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showAddProfileDialog() {
        val types = arrayOf("M3U / M3U8 playlist", "Xtream Codes account")
        AlertDialog.Builder(this).setTitle("Choose account type")
            .setItems(types) { _, which ->
                if (which == 0) showSaveM3uProfileDialog() else showSaveXtreamProfileDialog()
            }.show()
    }

    private fun profileForm(vararg fields: Pair<String, Int>): Pair<LinearLayout, List<EditText>> {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(42, 20, 42, 8)
        }
        val inputs = fields.map { (hintText, inputType) ->
            EditText(this).apply {
                hint = hintText
                setSingleLine(true)
                this.inputType = inputType
                box.addView(this)
            }
        }
        return box to inputs
    }

    private fun showSaveM3uProfileDialog() {
        val (box, e) = profileForm(
            "Account name (e.g. Family TV)" to InputType.TYPE_CLASS_TEXT,
            "M3U URL or playlist text" to (InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI)
        )
        AlertDialog.Builder(this).setTitle("Save M3U playlist").setView(box)
            .setPositiveButton("Save & Play") { _, _ ->
                val name = e[0].text.toString().trim()
                val source = e[1].text.toString().trim()
                if (name.isBlank() || source.isBlank()) {
                    Toast.makeText(this, "Name and playlist are required", Toast.LENGTH_LONG).show()
                } else {
                    val p = PlaylistProfile(name = name, type = ProfileType.M3U, source = source)
                    profileStore.save(p); profileStore.setActive(p.id); activateProfile(p)
                }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showSaveXtreamProfileDialog() {
        val (box, e) = profileForm(
            "Account name (e.g. Sports)" to InputType.TYPE_CLASS_TEXT,
            "Server URL" to (InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI),
            "Username" to InputType.TYPE_CLASS_TEXT,
            "Password" to (InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        )
        AlertDialog.Builder(this).setTitle("Save Xtream account").setView(box)
            .setPositiveButton("Save & Play") { _, _ ->
                val name = e[0].text.toString().trim()
                val server = e[1].text.toString().trim()
                val user = e[2].text.toString().trim()
                val pass = e[3].text.toString()
                if (name.isBlank() || server.isBlank() || user.isBlank() || pass.isBlank()) {
                    Toast.makeText(this, "All fields are required", Toast.LENGTH_LONG).show()
                } else {
                    val p = PlaylistProfile(
                        name = name,
                        type = ProfileType.XTREAM,
                        source = server,
                        username = user,
                        password = pass
                    )
                    profileStore.save(p); profileStore.setActive(p.id); activateProfile(p)
                }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showDeleteProfileDialog() {
        val profiles = profileStore.all()
        if (profiles.isEmpty()) {
            Toast.makeText(this, "No saved accounts", Toast.LENGTH_SHORT).show(); return
        }
        AlertDialog.Builder(this).setTitle("Delete saved account")
            .setItems(profiles.map { "${it.name} (${it.type})" }.toTypedArray()) { _, which ->
                profileStore.delete(profiles[which].id)
                if (profileStore.activeId() == profiles[which].id) {
                    val next = profileStore.all().firstOrNull()
                    if (next != null) {
                        profileStore.setActive(next.id)
                        activateProfile(next)
                    } else {
                        Toast.makeText(this, "Account deleted. Add a playlist to start.", Toast.LENGTH_LONG).show()
                    }
                }
                showProfilesDialog()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun activateProfile(profile: PlaylistProfile) {
        profileStore.setActive(profile.id)
        tvActiveSectionBadge.text = "StreamX Media3 Pro • ${profile.name}"
        when (profile.type) {
            ProfileType.M3U -> loadM3uFromInput(profile.source, profile.name, forceNetworkRefresh = false)
            ProfileType.XTREAM -> loadXtreamChannels(
                XtreamCredentials(profile.name, profile.source, profile.username, profile.password),
                forceNetworkRefresh = false
            )
        }
    }

    private fun showXtreamLoginDialog() {
        val prefs = getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 32, 48, 16)
        }
        val etServer = EditText(this).apply {
            hint = "Server URL (e.g. http://line.server.com:8080)"
            setText(prefs.getString("xtream_server", ""))
        }
        val etUser = EditText(this).apply {
            hint = "Username"
            setText(prefs.getString("xtream_user", ""))
        }
        val etPass = EditText(this).apply {
            hint = "Password"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("xtream_pass", ""))
        }
        layout.addView(etServer)
        layout.addView(etUser)
        layout.addView(etPass)

        AlertDialog.Builder(this)
            .setTitle("🔑 Xtream Codes API Login")
            .setView(layout)
            .setPositiveButton("Connect & Play") { _, _ ->
                val srv = etServer.text.toString().trim()
                val usr = etUser.text.toString().trim()
                val pwd = etPass.text.toString().trim()
                if (srv.isNotEmpty() && usr.isNotEmpty()) {
                    prefs.edit()
                        .putString("xtream_server", srv)
                        .putString("xtream_user", usr)
                        .putString("xtream_pass", pwd)
                        .apply()
                    loadXtreamChannels(XtreamCredentials("TV", srv, usr, pwd), forceNetworkRefresh = true)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun loadXtreamChannels(creds: XtreamCredentials, forceNetworkRefresh: Boolean = false) {
        activeSourceType = ProfileType.XTREAM
        activeXtreamCreds = creds
        val cKey = cacheKeyFor("xtream_${creds.serverUrl.trim()}_${creds.username.trim()}")

        loadChannelsJob?.cancel()
        loadChannelsJob = lifecycleScope.launch {
            val t0 = SystemClock.elapsedRealtime()

            if (!forceNetworkRefresh) {
                updateBootStage(68, "Restoring cached channels...", "Account: ${creds.profileName}")
                val cached = channelCache.loadChannels(cKey, maxLimit = maxPlaylistLimit) { firstBatch ->
                    withContext(Dispatchers.Main) {
                        if (isBootOverlayVisible) {
                            updateBootStage(74, "Restoring Your Channels (${firstBatch.size}+)...", "Progressive instant load")
                        }
                    }
                }
                if (cached.isNotEmpty()) {
                    lastPlaylistLoadDurationMs = SystemClock.elapsedRealtime() - t0
                    applyLoadedChannels(
                        cached,
                        "StreamX Pro • ⚡ ${creds.profileName} (${cached.size} CH)",
                        resumeLastWatched = true
                    )
                    if (isNetworkConnectedNow() && channelCache.isCacheStale(cKey)) {
                        scheduleSilentXtreamRefresh(creds, cKey)
                    }
                    return@launch
                }
            }

            updateBootStage(70, "Loading Your Playlist from Server...", "Connecting to ${creds.serverUrl}")
            tvActiveSectionBadge.text = "⏳ Loading Xtream Channels..."
            val res = xtreamRepo.fetchLiveStreams(creds, maxStreams = maxPlaylistLimit) { firstBatch ->
                withContext(Dispatchers.Main) {
                    updateBootStage(76, "Loaded first ${firstBatch.size} channels...", "Streaming remaining playlist in background")
                    applyLoadedChannels(
                        firstBatch,
                        "StreamX Pro • ⏳ ${creds.profileName} (${firstBatch.size}+ CH)",
                        resumeLastWatched = false,
                        isPreliminaryBatch = true
                    )
                }
            }
            res.onSuccess { list ->
                lastPlaylistLoadDurationMs = SystemClock.elapsedRealtime() - t0
                if (list.isNotEmpty()) {
                    applyLoadedChannels(
                        list,
                        "StreamX Pro • ${creds.profileName} (${list.size} CH)",
                        resumeLastWatched = true
                    )
                    launch(Dispatchers.IO) {
                        channelCache.saveChannels(cKey, list, maxLimit = maxPlaylistLimit)
                    }
                    Toast.makeText(
                        this@PlayerActivity,
                        "Xtream Connected & Cached: ${list.size} Channels!",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    dismissDthBootOverlay("NO CHANNELS FOUND")
                    tvActiveSectionBadge.text = "StreamX Media3 Pro • No Channels"
                    Toast.makeText(this@PlayerActivity, "No live channels found on server", Toast.LENGTH_LONG).show()
                }
            }.onFailure { err ->
                Log.w("StreamX", "Xtream load error", err)
                val fallbackCached = channelCache.loadChannels(cKey, maxLimit = maxPlaylistLimit)
                if (fallbackCached.isNotEmpty()) {
                    updateBootStage(85, "Network unavailable – Loading saved channels.", "Restored ${fallbackCached.size} channels")
                    applyLoadedChannels(
                        fallbackCached,
                        "StreamX Pro • ⚡ ${creds.profileName} (${fallbackCached.size} CH)",
                        resumeLastWatched = true
                    )
                    Toast.makeText(
                        this@PlayerActivity,
                        "Network unavailable – Loaded ${fallbackCached.size} saved channels",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    dismissDthBootOverlay("CONNECTION ERROR")
                    tvActiveSectionBadge.text = "StreamX Media3 Pro • Connection Error"
                    Toast.makeText(this@PlayerActivity, "Xtream Error: ${err.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun scheduleSilentXtreamRefresh(creds: XtreamCredentials, cKey: String) {
        bgSyncJob?.cancel()
        bgSyncJob = lifecycleScope.launch(Dispatchers.IO) {
            delay(4000L)
            val res = xtreamRepo.fetchLiveStreams(creds, maxStreams = maxPlaylistLimit)
            res.onSuccess { freshList ->
                if (freshList.isNotEmpty()) {
                    channelCache.saveChannels(cKey, freshList, maxLimit = maxPlaylistLimit)
                }
            }
        }
    }

    private fun showM3uLoadDialog() {
        val prefs = getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
        val etM3u = EditText(this).apply {
            hint = "Paste M3U URL (https://.../playlist.m3u) or #EXTM3U"
            setText(prefs.getString("m3u_url", ""))
        }
        AlertDialog.Builder(this)
            .setTitle("📂 Load M3U / M3U8 Playlist")
            .setView(etM3u)
            .setNeutralButton("Choose local file") { _, _ ->
                playlistPicker.launch(arrayOf("application/x-mpegURL", "audio/x-mpegurl", "text/plain", "*/*"))
            }
            .setPositiveButton("Load Channels") { _, _ ->
                val input = etM3u.text.toString().trim()
                if (input.isNotEmpty()) {
                    prefs.edit().putString("m3u_url", input).apply()
                    loadM3uFromInput(input, "M3U", forceNetworkRefresh = true)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun loadM3uFromInput(input: String, label: String = "M3U", forceNetworkRefresh: Boolean = false) {
        activeSourceType = ProfileType.M3U
        activeM3uInput = input
        activeM3uLabel = label
        val cKey = cacheKeyFor("m3u_${input.take(256)}")

        loadChannelsJob?.cancel()
        loadChannelsJob = lifecycleScope.launch {
            val t0 = SystemClock.elapsedRealtime()
            if (!forceNetworkRefresh) {
                updateBootStage(68, "Restoring cached M3U playlist...", label)
                val cached = channelCache.loadChannels(cKey, maxLimit = maxPlaylistLimit)
                if (cached.isNotEmpty()) {
                    lastPlaylistLoadDurationMs = SystemClock.elapsedRealtime() - t0
                    applyLoadedChannels(
                        cached,
                        "StreamX Pro • ⚡ $label (${cached.size} CH)",
                        resumeLastWatched = true
                    )
                    if (isNetworkConnectedNow() &&
                        (input.startsWith("http://", true) || input.startsWith("https://", true)) &&
                        channelCache.isCacheStale(cKey)
                    ) {
                        scheduleSilentM3uRefresh(input, cKey)
                    }
                    return@launch
                }
            }

            updateBootStage(72, "Loading M3U Playlist...", label)
            tvActiveSectionBadge.text = "⏳ Loading M3U Playlist..."
            try {
                val parsed = withContext(Dispatchers.IO) {
                    when {
                        input.startsWith("http://", true) || input.startsWith("https://", true) -> {
                            NetworkClient.apiClient.newCall(Request.Builder().url(input).build()).execute().use { res ->
                                if (!res.isSuccessful) error("Playlist HTTP ${res.code}")
                                val body = res.body ?: error("Empty M3U response")
                                BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8), 32768).use { reader ->
                                    M3uParser.parse(reader, maxChannels = maxPlaylistLimit, shouldCancel = { !isActive })
                                }
                            }
                        }
                        input.startsWith("file://", true) -> {
                            val file = File(Uri.parse(input).path ?: "")
                            if (!file.exists()) error("Saved playlist file not found")
                            file.bufferedReader(Charsets.UTF_8).use { reader ->
                                M3uParser.parse(reader, maxChannels = maxPlaylistLimit, shouldCancel = { !isActive })
                            }
                        }
                        input.startsWith("content://", true) -> {
                            contentResolver.openInputStream(Uri.parse(input))?.bufferedReader(Charsets.UTF_8)?.use { reader ->
                                M3uParser.parse(reader, maxChannels = maxPlaylistLimit, shouldCancel = { !isActive })
                            } ?: emptyList()
                        }
                        else -> M3uParser.parse(input, maxChannels = maxPlaylistLimit, shouldCancel = { !isActive })
                    }
                }
                lastPlaylistLoadDurationMs = SystemClock.elapsedRealtime() - t0
                if (parsed.isNotEmpty()) {
                    applyLoadedChannels(
                        parsed,
                        "StreamX Pro • $label (${parsed.size} CH)",
                        resumeLastWatched = true
                    )
                    launch(Dispatchers.IO) {
                        channelCache.saveChannels(cKey, parsed, maxLimit = maxPlaylistLimit)
                    }
                    Toast.makeText(this@PlayerActivity, "M3U Loaded & Cached: ${parsed.size} Channels!", Toast.LENGTH_SHORT).show()
                } else {
                    dismissDthBootOverlay("NO CHANNELS FOUND")
                    tvActiveSectionBadge.text = "StreamX Media3 Pro • All Live TV"
                    Toast.makeText(this@PlayerActivity, "No valid channels found in M3U", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Log.w("StreamX", "M3U load error", e)
                val fallbackCached = channelCache.loadChannels(cKey, maxLimit = maxPlaylistLimit)
                if (fallbackCached.isNotEmpty()) {
                    updateBootStage(85, "Network unavailable – Loading saved channels.", "Restored ${fallbackCached.size} channels")
                    applyLoadedChannels(
                        fallbackCached,
                        "StreamX Pro • ⚡ $label (${fallbackCached.size} CH)",
                        resumeLastWatched = true
                    )
                } else {
                    dismissDthBootOverlay("CONNECTION ERROR")
                    tvActiveSectionBadge.text = "StreamX Media3 Pro • M3U Error"
                    Toast.makeText(this@PlayerActivity, "M3U Error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun scheduleSilentM3uRefresh(url: String, cKey: String) {
        bgSyncJob?.cancel()
        bgSyncJob = lifecycleScope.launch(Dispatchers.IO) {
            delay(4000L)
            runCatching {
                NetworkClient.apiClient.newCall(Request.Builder().url(url).build()).execute().use { res ->
                    if (!res.isSuccessful) return@use
                    val body = res.body ?: return@use
                    val parsed = BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8), 32768).use { reader ->
                        M3uParser.parse(reader, maxChannels = maxPlaylistLimit, shouldCancel = { !isActive })
                    }
                    if (parsed.isNotEmpty()) {
                        channelCache.saveChannels(cKey, parsed, maxLimit = maxPlaylistLimit)
                    }
                }
            }
        }
    }

    private suspend fun restoreSavedDataFromBoot(prefs: android.content.SharedPreferences, hasNet: Boolean) {
        if (!autoResumeEnabled) {
            updateBootStage(90, "Preparing Live Television...", "Starting default stream")
            switchChannel(0, immediatePlayback = true)
            dismissDthBootOverlay("READY TO ADD PLAYLIST")
            return
        }

        if (prefs.getBoolean("has_saved_profiles", false)) {
            val savedProfiles = withContext(Dispatchers.IO) { profileStore.all() }
            val activeId = withContext(Dispatchers.IO) { profileStore.activeId() }
            val active = savedProfiles.firstOrNull { it.id == activeId } ?: savedProfiles.firstOrNull()
            if (active != null) {
                profileStore.setActive(active.id)
                if (!hasNet) {
                    updateBootStage(70, "Network unavailable – Loading saved channels.", active.name)
                }
                activateProfile(active)
                return
            }
        }

        val srv = prefs.getString("xtream_server", "") ?: ""
        val usr = prefs.getString("xtream_user", "") ?: ""
        val pwd = prefs.getString("xtream_pass", "") ?: ""
        val m3u = prefs.getString("m3u_url", "") ?: ""
        if (srv.isNotEmpty() && usr.isNotEmpty()) {
            loadXtreamChannels(XtreamCredentials("Saved", srv, usr, pwd), forceNetworkRefresh = false)
        } else if (m3u.isNotEmpty()) {
            loadM3uFromInput(m3u, "Saved M3U", forceNetworkRefresh = false)
        } else {
            updateBootStage(90, "Preparing Live Television...", "Ready to Watch")
            switchChannel(0, immediatePlayback = true)
            dismissDthBootOverlay("READY TO ADD PLAYLIST")
        }
    }

    private fun updateOsdForCurrentChannel() {
        if (allChannels.isEmpty() || currentChannelIndex !in allChannels.indices) return
        val channel = allChannels[currentChannelIndex]
        tvChannelNumber.text = when {
            channel.number < 10 -> "00${channel.number}"
            channel.number < 100 -> "0${channel.number}"
            else -> channel.number.toString()
        }
        tvChannelName.text = channel.name
        if (channel.logoUrl.isNotBlank() && !isDestroyed && !isFinishing) {
            Glide.with(this)
                .load(channel.logoUrl)
                .apply(logoRequestOptions)
                .into(channelLogo)
        } else {
            channelLogo.setImageResource(android.R.drawable.ic_media_play)
        }
        val epg = epgMap[channel.epgId.ifBlank { channel.id }]
        val telemetrySuffix = if (liveTelemetryDetail.isNotEmpty()) " • $liveTelemetryDetail" else ""
        tvChannelCategory.text = "${channel.category} • $liveResolutionLabel$telemetrySuffix • $liveStatusLabel"
        tvEpgNow.text = "Now: ${epg?.first ?: Channel.DEFAULT_PROGRAM}  |  Next: ${epg?.second ?: Channel.DEFAULT_NEXT_PROGRAM}  |  CH ${currentChannelIndex + 1}/${allChannels.size}"
        updateFavButtonUi(channel.id)
    }

    private fun switchChannel(newIndex: Int, immediatePlayback: Boolean = false) {
        if (allChannels.isEmpty()) return
        val resolvedIndex = ((newIndex % allChannels.size) + allChannels.size) % allChannels.size
        val targetChannel = allChannels[resolvedIndex]

        if (::profileStore.isInitialized &&
            profileStore.isCategoryLocked(targetChannel.category) &&
            !unlockedSessionCategories.contains(targetChannel.category.lowercase(Locale.ROOT))
        ) {
            promptParentalPinToUnlock(targetChannel.category) {
                switchChannel(resolvedIndex, immediatePlayback = true)
            }
            return
        }

        if (resolvedIndex != currentChannelIndex) {
            previousChannelIndex = currentChannelIndex
        }
        currentChannelIndex = resolvedIndex
        val channel = allChannels[currentChannelIndex]
        playbackRetryCount = 0
        stallRecoveryCount = 0
        usingBackupStream = false
        liveTelemetryDetail = ""
        lastSwitchStartElapsedMs = SystemClock.elapsedRealtime()
        liveStatusLabel = "⏳ Connecting..."

        recentIds.remove(channel.id)
        recentIds.add(0, channel.id)
        if (recentIds.size > 20) recentIds.removeAt(recentIds.lastIndex)
        uiHandler.removeCallbacks(persistStateRunnable)
        uiHandler.postDelayed(persistStateRunnable, 500L)

        updateOsdForCurrentChannel()
        showZappingOsd()

        if (leftChannelDrawer.visibility == View.VISIBLE && activeTab == "RECENT") {
            renderDrawerList()
        } else {
            channelAdapter.updateActiveChannel(currentChannelIndex)
        }

        uiHandler.removeCallbacks(stallWatchdogRunnable)
        uiHandler.removeCallbacks(retryPlaybackRunnable)
        uiHandler.removeCallbacks(commitPlaybackRunnable)
        if (immediatePlayback) {
            startPlaybackForCurrentChannel(forceReload = false)
        } else {
            uiHandler.postDelayed(commitPlaybackRunnable, 80L)
        }
    }

    private fun startPlaybackForCurrentChannel(forceReload: Boolean = false) {
        if (allChannels.isEmpty() || currentChannelIndex !in allChannels.indices) return
        val channel = allChannels[currentChannelIndex]
        if (::profileStore.isInitialized) {
            val savedLang = profileStore.getPreferredAudioLanguage(channel.id)
            exoPlayer?.let { player ->
                val b = player.trackSelectionParameters.buildUpon()
                if (!savedLang.isNullOrBlank()) {
                    b.setPreferredAudioLanguages(savedLang, "hi", "hin", "en", "eng")
                } else {
                    b.setPreferredAudioLanguages("hi", "hin", "en", "eng")
                }
                player.trackSelectionParameters = b.build()
            }
        }
        playSpecificStreamUrl(channel.streamUrl, forceReload = forceReload)
    }

    // Upgrade 1: Instantaneous <80ms Surface Swap when NextPrewarmPlayer or PrevPrewarmPlayer matches targetUrl
    private fun playSpecificStreamUrl(targetUrl: String, forceReload: Boolean = false) {
        val currentActive = exoPlayer ?: return
        if (!forceReload &&
            currentPlayingStreamUrl == targetUrl &&
            (currentActive.playbackState == Player.STATE_READY || currentActive.playbackState == Player.STATE_BUFFERING)
        ) {
            currentActive.playWhenReady = true
            return
        }

        // Check if Slot 2 (NextPrewarmPlayer) has already pre-warmed targetUrl!
        val candidateNext = nextPrewarmPlayer
        if (!forceReload &&
            candidateNext != null &&
            nextPrewarmUrl == targetUrl &&
            (candidateNext.playbackState == Player.STATE_READY || candidateNext.playbackState == Player.STATE_BUFFERING)
        ) {
            swapPrewarmSlotIntoActive(candidateNext, isFromNextSlot = true, targetUrl = targetUrl)
            return
        }

        // Check if Slot 3 (PrevPrewarmPlayer) has already pre-warmed targetUrl!
        val candidatePrev = prevPrewarmPlayer
        if (!forceReload &&
            candidatePrev != null &&
            prevPrewarmUrl == targetUrl &&
            (candidatePrev.playbackState == Player.STATE_READY || candidatePrev.playbackState == Player.STATE_BUFFERING)
        ) {
            swapPrewarmSlotIntoActive(candidatePrev, isFromNextSlot = false, targetUrl = targetUrl)
            return
        }

        currentPlayingStreamUrl = targetUrl
        bindUrlToPlayer(currentActive, targetUrl)
        currentActive.prepare()
        currentActive.playWhenReady = true
    }

    private fun swapPrewarmSlotIntoActive(promotedPlayer: ExoPlayer, isFromNextSlot: Boolean, targetUrl: String) {
        val oldActive = exoPlayer
        oldActive?.removeListener(activePlayerListener)
        oldActive?.playWhenReady = false
        oldActive?.volume = 0f

        exoPlayer = promotedPlayer
        currentPlayingStreamUrl = targetUrl
        playerView.player = promotedPlayer
        promotedPlayer.addListener(activePlayerListener)
        promotedPlayer.volume = 1f
        promotedPlayer.playWhenReady = true

        if (promotedPlayer.playbackState == Player.STATE_READY) {
            lastChannelSwitchMs = SystemClock.elapsedRealtime() - lastSwitchStartElapsedMs
            liveStatusLabel = "🟢 Live (3-Slot Instant Swap)"
            updateLiveTelemetryBadge(promotedPlayer)
            updateOsdForCurrentChannel()
        }

        if (isFromNextSlot) {
            nextPrewarmPlayer = oldActive
            nextPrewarmUrl = ""
        } else {
            prevPrewarmPlayer = oldActive
            prevPrewarmUrl = ""
        }

        uiHandler.removeCallbacks(prewarmAdjacentSlotsRunnable)
        uiHandler.postDelayed(prewarmAdjacentSlotsRunnable, 280L)
    }

    private fun showZappingOsd() {
        osdBanner.alpha = 1f
        osdBanner.visibility = View.VISIBLE
        topControlBar.visibility = View.VISIBLE
        uiHandler.removeCallbacks(hideOsdRunnable)
        uiHandler.postDelayed(hideOsdRunnable, 3000L)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val isKeyRepeat = (event?.repeatCount ?: 0) > 0
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP -> {
                if (leftChannelDrawer.visibility != View.VISIBLE) {
                    switchChannel(currentChannelIndex + 1, immediatePlayback = !isKeyRepeat)
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> {
                if (leftChannelDrawer.visibility != View.VISIBLE) {
                    switchChannel(currentChannelIndex - 1, immediatePlayback = !isKeyRepeat)
                    return true
                }
            }
            KeyEvent.KEYCODE_MEDIA_REWIND -> {
                exoPlayer?.seekBack()
                liveStatusLabel = "⏪ Rewind -10s"
                updateOsdForCurrentChannel()
                showZappingOsd()
                return true
            }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                exoPlayer?.seekForward()
                liveStatusLabel = "⏩ Forward +10s"
                updateOsdForCurrentChannel()
                showZappingOsd()
                return true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (leftChannelDrawer.visibility != View.VISIBLE) {
                    openDrawerAndRequestFocus()
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_LAST_CHANNEL, KeyEvent.KEYCODE_MEDIA_PREVIOUS, KeyEvent.KEYCODE_DEL -> {
                if (leftChannelDrawer.visibility != View.VISIBLE) {
                    recallPreviousChannel()
                    return true
                }
            }
            KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_PROG_YELLOW -> {
                showAudioAndQualityDialog()
                return true
            }
            KeyEvent.KEYCODE_PROG_BLUE -> {
                showThemeAndPipDialog()
                return true
            }
            KeyEvent.KEYCODE_BACK -> {
                if (leftChannelDrawer.visibility == View.VISIBLE) {
                    closeDrawerAndRestoreFocus()
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                if (numberInputBuffer.isNotEmpty()) {
                    uiHandler.removeCallbacks(numberJumpRunnable)
                    numberJumpRunnable.run()
                    return true
                }
                if (leftChannelDrawer.visibility != View.VISIBLE) {
                    showZappingOsd()
                    return true
                }
            }
            in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> {
                val digit = keyCode - KeyEvent.KEYCODE_0
                if (numberInputBuffer.length < 5) {
                    numberInputBuffer += digit.toString()
                }
                tvChannelNumber.text = numberInputBuffer.padStart(3, '-')
                osdBanner.alpha = 1f
                osdBanner.visibility = View.VISIBLE
                uiHandler.removeCallbacks(numberJumpRunnable)
                uiHandler.postDelayed(numberJumpRunnable, 850L)
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun registerNetworkCallbackSafe() {
        if (networkCallbackRegistered) return
        val cm = connectivityManager ?: return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                cm.registerDefaultNetworkCallback(networkCallback)
            } else {
                val req = NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build()
                cm.registerNetworkCallback(req, networkCallback)
            }
            networkCallbackRegistered = true
        } catch (e: Exception) {
            Log.w("StreamX", "NetworkCallback registration warning: ${e.message}")
        }
    }

    private fun unregisterNetworkCallbackSafe() {
        if (!networkCallbackRegistered) return
        try {
            connectivityManager?.unregisterNetworkCallback(networkCallback)
        } catch (e: Exception) {
            Log.w("StreamX", "NetworkCallback unregister warning: ${e.message}")
        } finally {
            networkCallbackRegistered = false
        }
    }

    override fun onStart() {
        super.onStart()
        registerNetworkCallbackSafe()
        exoPlayer?.let { player ->
            if (player.mediaItemCount > 0) {
                if (player.playbackState == Player.STATE_IDLE) {
                    player.seekToDefaultPosition()
                    player.prepare()
                }
                player.playWhenReady = true
            }
        }
    }

    override fun onStop() {
        super.onStop()
        val inPip = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) isInPictureInPictureMode else false
        if (!inPip) {
            unregisterNetworkCallbackSafe()
            StreamPreFetcher.cancelAllPrefetches()
            uiHandler.removeCallbacks(prewarmAdjacentSlotsRunnable)
            uiHandler.removeCallbacks(stallWatchdogRunnable)
            uiHandler.removeCallbacks(persistStateRunnable)
            persistStateRunnable.run()
            exoPlayer?.pause()
            runCatching { nextPrewarmPlayer?.release() }
            runCatching { prevPrewarmPlayer?.release() }
            nextPrewarmPlayer = null
            prevPrewarmPlayer = null
            nextPrewarmUrl = ""
            prevPrewarmUrl = ""
        }
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        runCatching {
            Glide.get(this).trimMemory(level)
            if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL) {
                Glide.get(this).clearMemory()
                StreamPreFetcher.trimIdleCacheOnLowMemory()
                sharedAllocator?.trim()
            }
        }
    }

    override fun onLowMemory() {
        super.onLowMemory()
        runCatching {
            Glide.get(this).clearMemory()
            StreamPreFetcher.trimIdleCacheOnLowMemory()
            sharedAllocator?.trim()
        }
    }

    override fun onDestroy() {
        cancelBootAnimators()
        unregisterNetworkCallbackSafe()
        StreamPreFetcher.cancelAllPrefetches()
        filterJob?.cancel()
        loadChannelsJob?.cancel()
        epgLoadJob?.cancel()
        bgSyncJob?.cancel()
        uiHandler.removeCallbacksAndMessages(null)
        releaseAllPlayerSlots()
        super.onDestroy()
    }

    private class ChannelDrawerAdapter(
        private val channelProvider: (Int) -> Channel?,
        private val isFavorite: (String) -> Boolean,
        private val onChannelClick: (Int) -> Unit,
        private val onChannelFocused: (Int) -> Unit
    ) : RecyclerView.Adapter<ChannelDrawerAdapter.ChannelViewHolder>() {

        companion object {
            private const val PAYLOAD_ACTIVE_STATE = 1
            private const val PAYLOAD_FAVORITE_STATE = 2
        }

        private var indices: IntArray = IntArray(0)
        private var indicesAscending: Boolean = true
        private var activeGlobalIndex: Int = 0
        private var activeAccentColor: Int = Color.parseColor("#0284C7")
        private val inactiveRowColor: Int = Color.parseColor("#1E293B")
        private val focusedRowColor: Int = Color.parseColor("#0369A1")
        private val rowStringBuilder = StringBuilder(96)

        init {
            setHasStableIds(true)
        }

        fun currentIndices(): IntArray = indices

        private fun findAdapterPos(globalIndex: Int): Int {
            if (indices.isEmpty()) return -1
            if (indicesAscending) {
                val pos = Arrays.binarySearch(indices, globalIndex)
                return if (pos >= 0) pos else -1
            }
            return indices.indexOfFirst { it == globalIndex }
        }

        fun setAccentColor(color: Int) {
            if (activeAccentColor == color) return
            activeAccentColor = color
            val activePos = findAdapterPos(activeGlobalIndex)
            if (activePos != -1) {
                notifyItemChanged(activePos, PAYLOAD_ACTIVE_STATE)
            }
        }

        fun submitIndices(
            newIndices: IntArray,
            currentGlobalIndex: Int,
            diffResult: DiffUtil.DiffResult?,
            isAscending: Boolean = true
        ) {
            val prevActiveGlobal = activeGlobalIndex
            indices = newIndices
            indicesAscending = isAscending
            activeGlobalIndex = currentGlobalIndex
            if (diffResult != null) {
                diffResult.dispatchUpdatesTo(this)
                if (prevActiveGlobal != currentGlobalIndex) {
                    val oldPos = findAdapterPos(prevActiveGlobal)
                    val newPos = findAdapterPos(currentGlobalIndex)
                    if (oldPos != -1) notifyItemChanged(oldPos, PAYLOAD_ACTIVE_STATE)
                    if (newPos != -1) notifyItemChanged(newPos, PAYLOAD_ACTIVE_STATE)
                }
            } else {
                notifyDataSetChanged()
            }
        }

        fun updateActiveChannel(newGlobalIndex: Int) {
            if (activeGlobalIndex == newGlobalIndex) return
            val oldGlobal = activeGlobalIndex
            activeGlobalIndex = newGlobalIndex
            val oldPos = findAdapterPos(oldGlobal)
            val newPos = findAdapterPos(newGlobalIndex)
            if (oldPos != -1) notifyItemChanged(oldPos, PAYLOAD_ACTIVE_STATE)
            if (newPos != -1) notifyItemChanged(newPos, PAYLOAD_ACTIVE_STATE)
        }

        fun notifyFavoriteChanged(globalIndex: Int) {
            val pos = findAdapterPos(globalIndex)
            if (pos != -1) notifyItemChanged(pos, PAYLOAD_FAVORITE_STATE)
        }

        override fun getItemId(position: Int): Long = indices[position].toLong()

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChannelViewHolder {
            val btn = Button(parent.context).apply {
                isAllCaps = false
                setTextColor(Color.WHITE)
                textSize = 13f
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(24, 14, 24, 14)
                isFocusable = true
                layoutParams = RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = 8
                }
            }
            return ChannelViewHolder(btn, onChannelClick, onChannelFocused) { globalIdx, hasFocus ->
                when {
                    hasFocus -> focusedRowColor
                    globalIdx == activeGlobalIndex -> activeAccentColor
                    else -> inactiveRowColor
                }
            }
        }

        override fun onBindViewHolder(
            holder: ChannelViewHolder,
            position: Int,
            payloads: MutableList<Any>
        ) {
            if (payloads.isEmpty()) {
                onBindViewHolder(holder, position)
                return
            }
            val globalIdx = indices[position]
            val ch = channelProvider(globalIdx) ?: return
            for (payload in payloads) {
                when (payload) {
                    PAYLOAD_ACTIVE_STATE -> {
                        val isSelected = globalIdx == activeGlobalIndex
                        holder.button.setBackgroundColor(if (isSelected) activeAccentColor else inactiveRowColor)
                    }
                    PAYLOAD_FAVORITE_STATE -> {
                        bindRowText(holder.button, ch)
                    }
                }
            }
        }

        override fun onBindViewHolder(holder: ChannelViewHolder, position: Int) {
            val globalIdx = indices[position]
            holder.boundGlobalIndex = globalIdx
            val ch = channelProvider(globalIdx) ?: return
            bindRowText(holder.button, ch)
            val isSelected = globalIdx == activeGlobalIndex
            holder.button.setBackgroundColor(if (isSelected) activeAccentColor else inactiveRowColor)
        }

        private fun bindRowText(button: Button, ch: Channel) {
            rowStringBuilder.setLength(0)
            if (ch.number < 10) {
                rowStringBuilder.append("00").append(ch.number)
            } else if (ch.number < 100) {
                rowStringBuilder.append('0').append(ch.number)
            } else {
                rowStringBuilder.append(ch.number)
            }
            rowStringBuilder.append("  ")
            if (isFavorite(ch.id)) {
                rowStringBuilder.append("★ ")
            }
            rowStringBuilder.append(ch.name).append(" (").append(ch.category).append(')')
            button.text = rowStringBuilder.toString()
        }

        override fun getItemCount(): Int = indices.size

        class ChannelViewHolder(
            val button: Button,
            onChannelClick: (Int) -> Unit,
            onChannelFocused: (Int) -> Unit,
            resolveColor: (Int, Boolean) -> Int
        ) : RecyclerView.ViewHolder(button) {
            var boundGlobalIndex: Int = -1

            init {
                button.setOnClickListener {
                    if (boundGlobalIndex >= 0) {
                        onChannelClick(boundGlobalIndex)
                    }
                }
                button.setOnFocusChangeListener { _, hasFocus ->
                    if (boundGlobalIndex >= 0) {
                        button.setBackgroundColor(resolveColor(boundGlobalIndex, hasFocus))
                        if (hasFocus) {
                            onChannelFocused(boundGlobalIndex)
                        }
                    }
                }
            }
        }
    }
}
