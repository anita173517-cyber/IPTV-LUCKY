package com.harindra.iptvpro

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.CacheWriter
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.datasource.okhttp.OkHttpDataSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.util.Collections

/**
 * v12.0 Apex 4GB Flagship Edition — 48MB SimpleCache + 3-Tier Smart Background CacheWriter Pre-Fetcher.
 *
 * Tier 1: Adjacent Channels (N+1 & N-1) — pre-warms manifest + up to 1 MB after playback starts.
 * Tier 2: D-Pad List Focus Pre-Fetch (>180ms focus) — pre-warms manifest + up to 512 KB before OK is pressed.
 * Tier 3: Top-10 Favorites/Recents Round-Robin Warmup — pre-warms manifest + up to 384 KB during idle playback.
 */
@OptIn(UnstableApi::class)
object StreamPreFetcher {
    const val MAX_SIMPLE_CACHE_BYTES = 48L * 1024L * 1024L // Expanded to 48 MB for 4GB RAM Apex Edition (Upgrade 2)
    private const val TIER1_ADJACENT_BYTES = 1024L * 1024L          // 1 MB
    private const val TIER2_FOCUS_BYTES = 512L * 1024L              // 512 KB
    private const val TIER3_WARMUP_BYTES = 384L * 1024L             // 384 KB

    @Volatile
    private var simpleCache: SimpleCache? = null
    private var cacheDirFile: File? = null

    private val prefetchScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var adjacentJob: Job? = null
    private var focusJob: Job? = null
    private var top10WarmupJob: Job? = null

    private val warmedUrls = Collections.synchronizedSet(LinkedHashSet<String>(128))

    @Synchronized
    fun getOrCreateSimpleCache(context: Context): SimpleCache {
        simpleCache?.let { return it }
        val dir = File(context.applicationContext.cacheDir, "streamx_apex_48mb_zap_cache")
        if (!dir.exists()) dir.mkdirs()
        cacheDirFile = dir
        val evictor = LeastRecentlyUsedCacheEvictor(MAX_SIMPLE_CACHE_BYTES)
        val dbProvider = StandaloneDatabaseProvider(context.applicationContext)
        return SimpleCache(dir, evictor, dbProvider).also {
            simpleCache = it
        }
    }

    fun buildCacheDataSourceFactory(
        context: Context,
        upstreamFactory: OkHttpDataSource.Factory
    ): CacheDataSource.Factory {
        val cache = getOrCreateSimpleCache(context)
        return CacheDataSource.Factory()
            .setCache(cache)
            .setUpstreamDataSourceFactory(upstreamFactory)
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
    }

    fun scheduleAdjacentPrefetch(
        context: Context,
        nextUrl: String?,
        prevUrl: String?
    ) {
        adjacentJob?.cancel()
        adjacentJob = prefetchScope.launch {
            delay(450L)
            if (!isActive) return@launch
            if (!nextUrl.isNullOrBlank()) {
                prewarmUrlPrefix(context, nextUrl, TIER1_ADJACENT_BYTES)
            }
            if (!isActive) return@launch
            if (!prevUrl.isNullOrBlank() && prevUrl != nextUrl) {
                prewarmUrlPrefix(context, prevUrl, TIER1_ADJACENT_BYTES)
            }
        }
    }

    fun scheduleFocusPrefetch(context: Context, focusedUrl: String?) {
        focusJob?.cancel()
        if (focusedUrl.isNullOrBlank()) return
        focusJob = prefetchScope.launch {
            delay(180L)
            if (!isActive) return@launch
            prewarmUrlPrefix(context, focusedUrl, TIER2_FOCUS_BYTES)
        }
    }

    fun scheduleTop10Warmup(context: Context, topUrls: List<String>) {
        top10WarmupJob?.cancel()
        if (topUrls.isEmpty()) return
        top10WarmupJob = prefetchScope.launch {
            delay(2500L)
            for (url in topUrls.take(10)) {
                if (!isActive) break
                if (!warmedUrls.contains(url)) {
                    prewarmUrlPrefix(context, url, TIER3_WARMUP_BYTES)
                    delay(600L)
                }
            }
        }
    }

    private fun prewarmUrlPrefix(context: Context, streamUrl: String, maxBytes: Long) {
        if (!streamUrl.startsWith("http://", true) && !streamUrl.startsWith("https://", true)) return
        try {
            val cache = getOrCreateSimpleCache(context)
            val upstream = OkHttpDataSource.Factory(NetworkClient.fastMetaClient)
                .setUserAgent("StreamX-Media3Pro/12.0-Apex-4GB (AndroidTV)")
            val cacheDataSource = CacheDataSource.Factory()
                .setCache(cache)
                .setUpstreamDataSourceFactory(upstream)
                .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
                .createDataSource()

            val dataSpec = DataSpec.Builder()
                .setUri(Uri.parse(streamUrl))
                .setPosition(0L)
                .setLength(maxBytes)
                .build()

            val tempBuffer = ByteArray(32 * 1024)
            val writer = CacheWriter(
                cacheDataSource,
                dataSpec,
                tempBuffer
            ) { _, bytesCached, _ ->
                if (bytesCached >= maxBytes) {
                    throw InterruptedException("Prefetch budget reached")
                }
            }
            writer.cache()
            synchronized(warmedUrls) {
                if (warmedUrls.size >= 96) {
                    val first = warmedUrls.iterator().next()
                    warmedUrls.remove(first)
                }
                warmedUrls.add(streamUrl)
            }
        } catch (_: InterruptedException) {
            // Normal budget cap completion
        } catch (e: Exception) {
            Log.d("StreamX", "Prefetch skipped for $streamUrl: ${e.message}")
        }
    }

    fun cancelAllPrefetches() {
        adjacentJob?.cancel()
        focusJob?.cancel()
        top10WarmupJob?.cancel()
    }

    fun trimIdleCacheOnLowMemory() {
        cancelAllPrefetches()
        warmedUrls.clear()
    }

    fun cacheUsedBytes(): Long {
        return try {
            simpleCache?.cacheSpace ?: 0L
        } catch (_: Exception) {
            0L
        }
    }
}
