package com.harindra.iptvpro

import android.app.Application
import android.content.ComponentCallbacks2
import android.util.Log
import com.bumptech.glide.Glide
import com.bumptech.glide.MemoryCategory

/**
 * v12.0 Apex 4GB Flagship Application class.
 * Unlocks MemoryCategory.HIGH and initializes the 100MB disk cache + 36MB RAM LRU cache for 4K ARGB_8888 logos.
 */
class StreamXApp : Application() {
    override fun onCreate() {
        super.onCreate()
        runCatching {
            NetworkClient.initLogoDiskCache(cacheDir)
            Glide.get(this).setMemoryCategory(MemoryCategory.HIGH)
        }
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        runCatching {
            Glide.get(this).trimMemory(level)
            if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL) {
                Log.i("StreamX", "Critical memory signal (level=$level): trimming caches")
                NetworkClient.logoRamLruCache.evictAll()
                Glide.get(this).clearMemory()
                StreamPreFetcher.trimIdleCacheOnLowMemory()
            }
        }
    }

    override fun onLowMemory() {
        super.onLowMemory()
        runCatching {
            NetworkClient.logoRamLruCache.evictAll()
            Glide.get(this).clearMemory()
            StreamPreFetcher.trimIdleCacheOnLowMemory()
        }
    }
}
